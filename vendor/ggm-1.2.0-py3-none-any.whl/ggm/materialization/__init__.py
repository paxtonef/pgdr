"""
ggm.materialization — GGM P2.2 Runtime Materialization.

Transforms a resolved ResolvedConsumptionManifest (P1.3 output) into a
bounded, executable MaterializedGGMRuntime consumed through the generic
GGMConsumer contract (P1.2) — or a RuntimeMaterializationError if the
manifest cannot be materialized against current canonical GGM state.

Exactly three public concepts (§5):

  RuntimeMaterializer          — the one canonical materialization path
  MaterializedGGMRuntime       — the one generic runtime object
  RuntimeMaterializationError  — the bounded materialization failure channel

This package owns resolved-manifest -> executable-runtime materialization.
ggm.consumption owns declaration/resolution. The boundaries remain separate
(§4): nothing here re-runs ConsumptionResolver.
"""

from ggm.materialization.errors import (
    RuntimeMaterializationErrorType,
    RuntimeMaterializationError,
    CONSTRUCTOR_COUPLING_BLOCKER,
)
from ggm.materialization.runtime import MaterializedGGMRuntime
from ggm.materialization.materializer import RuntimeMaterializer

__all__ = [
    "RuntimeMaterializer",
    "MaterializedGGMRuntime",
    "RuntimeMaterializationError",
    "RuntimeMaterializationErrorType",
    "CONSTRUCTOR_COUPLING_BLOCKER",
]
