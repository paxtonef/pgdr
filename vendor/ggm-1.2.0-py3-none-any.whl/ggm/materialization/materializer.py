"""
ggm.materialization.materializer — the single canonical RuntimeMaterializer
(P2.2 Implementation Mandate v1 §7-§9, §12, §16).

    ResolvedConsumptionManifest
        -> RuntimeMaterializer.materialize()
        -> MaterializedGGMRuntime | RuntimeMaterializationError

There is exactly one canonical materialization path (§7). No alternate or
consumer-specific materializers exist.

Materialization reads canonical GGM state directly (D7, §12): the canonical
profile registry, the canonical mandatory invariant identity, the canonical
kernel/runtime version, the current contract version, and the frozen P1.2
operation vocabulary. No content hash or cryptographic fingerprint is used;
drift is detected by exact canonical-state comparison at materialization
time, and any incompatible drift prevents materialization.

This module NEVER:
  - runs ConsumptionResolver (materialization consumes its output; it does
    not re-resolve it — T24);
  - evaluates governance during construction (T25);
  - mutates the manifest (T23);
  - materializes ClaimStore or any persistence (D8 — persistence remains
    external to the minimal governance execution runtime);
  - modifies, copies, or reconstructs canonical profiles or invariants
    (D1/D4 — filtered registries hold references to canonical objects).
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, Dict, List, Optional, Union

from ggm.contract.types import CONTRACT_VERSION, RUNTIME_VERSION, Operation, GovernanceRequest
from ggm.consumption.types import ResolvedConsumptionManifest
from ggm.consumption.registry import (
    MANDATORY_INVARIANT_IDS,
    CANONICAL_KERNEL_VERSION,
    canonical_profile_registry,
    lookup_profile,
)
from ggm.invariants import InvariantEngine
from ggm.profiles import ProfileResolver
from ggm.governance import TransitionEngine, EscalationDetector, GovernanceDecisionEngine

from ggm.materialization.errors import (
    CONSTRUCTOR_COUPLING_BLOCKER,
    RuntimeMaterializationError,
    RuntimeMaterializationErrorType,
)
from ggm.materialization.runtime import MaterializedGGMRuntime, _MaterializedConsumer

__all__ = ["RuntimeMaterializer"]


# =============================================================================
# Frozen P2.1 capability dependency map (mandate §9), as data.
# =============================================================================
#
# Machinery required by each operation's CURRENT valid execution path:
#
#   TRANSITION        -> filtered canonical ProfileResolver + TransitionEngine
#                        + canonical InvariantEngine behavior. GGM-I08 travels
#                        through this path (independent_confirmation in
#                        TransitionEngine._check_requirements via
#                        InvariantEngine.verify_independent_confirmation).
#   CHECK_ESCALATION  -> EscalationDetector + canonical InvariantEngine
#                        behavior.
#   DECIDE            -> GovernanceDecisionEngine + ProfileResolver (profile
#                        resolution for the decision and its audit trace).
#                        Under contract v1.3 the valid DECIDE path cannot
#                        carry requested_transitions and never passes
#                        generated_representation, so it cannot execute
#                        TransitionEngine or EscalationDetector.
#
# ClaimStore appears in NO closure (D8).
_OPERATION_MACHINERY: Dict[Operation, tuple] = {
    Operation.TRANSITION: ("profile_resolver", "transition_engine", "invariant_engine"),
    Operation.CHECK_ESCALATION: ("escalation_detector", "invariant_engine"),
    Operation.DECIDE: ("governance_decision_engine", "profile_resolver"),
}

# Canonical constructor couplings (what each engine's __init__ mechanically
# requires), keyed by machinery name. Only engine-on-engine couplings are
# recorded (ProfileResolver's `registry` parameter is profile data, not
# machinery). Verified at materialization time against the actual canonical
# class signatures — the frozen P2.1 map must match live canonical code, and
# any divergence is itself canonical-state drift (D7).
_CONSTRUCTOR_PARAMS: Dict[str, tuple] = {
    "transition_engine": ("invariant_engine",),
    "escalation_detector": ("invariant_engine",),
    # P2.2 DECIDE constructor-coupling repair (Repair Mandate v1 §4):
    # GovernanceDecisionEngine now mechanically requires only
    # profile_resolver; transition_engine and escalation_detector are
    # optional constructor dependencies, supplied by the materializer when
    # (and only when) their operations are enabled.
    "governance_decision_engine": ("profile_resolver",),
}

# Constructor parameters that carry profile DATA rather than machinery, and
# are therefore excluded from the coupling check (ProfileResolver's registry
# is the filtered canonical profile registry built at M6, not an engine).
_DATA_PARAMS: Dict[str, tuple] = {
    "profile_resolver": ("registry",),
}

_ENGINE_CLASSES = {
    "invariant_engine": InvariantEngine,
    "profile_resolver": ProfileResolver,
    "transition_engine": TransitionEngine,
    "escalation_detector": EscalationDetector,
    "governance_decision_engine": GovernanceDecisionEngine,
}

# The only manifest schema version P2.2 materializes (P1.3 §8).
_SUPPORTED_MANIFEST_VERSION = "1.0"


class RuntimeMaterializer:
    """The one canonical materializer (§7). Stateless: every call reads
    current canonical GGM state fresh, so drift between manifest-resolution
    time and materialization time is always detected (D7/§12)."""

    def materialize(
        self,
        manifest: ResolvedConsumptionManifest,
    ) -> Union[MaterializedGGMRuntime, RuntimeMaterializationError]:

        # --------------------------------------------------------------
        # M1 — Validate manifest object (§8). Accept exactly
        # ResolvedConsumptionManifest; never the three axis inputs
        # (GovernanceProfileSelection / GGMCapabilityProfile /
        # DeploymentProfile), never a dict, never re-run the resolver.
        # --------------------------------------------------------------
        if not isinstance(manifest, ResolvedConsumptionManifest):
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.INVALID_MANIFEST,
                details=(
                    f"materialize() requires a ResolvedConsumptionManifest, "
                    f"got {type(manifest).__name__}"
                ),
            )

        if manifest.manifest_version != _SUPPORTED_MANIFEST_VERSION:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.UNSUPPORTED_MANIFEST_VERSION,
                details=(
                    f"manifest_version {manifest.manifest_version!r} is not supported; "
                    f"supported: {_SUPPORTED_MANIFEST_VERSION!r}"
                ),
                manifest_id=manifest.manifest_id or None,
            )

        # --------------------------------------------------------------
        # M2 — D7 drift check 1: contract version (§12.1)
        # --------------------------------------------------------------
        if manifest.contract_version != CONTRACT_VERSION:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.CONTRACT_VERSION_INCOMPATIBLE,
                details=(
                    f"manifest contract_version {manifest.contract_version!r} is incompatible "
                    f"with current CONTRACT_VERSION {CONTRACT_VERSION!r}"
                ),
                manifest_id=manifest.manifest_id or None,
            )

        # --------------------------------------------------------------
        # M3 — D7 drift check 2: mandatory kernel version (§12.2). D6:
        # runtime/kernel version are one shared canonical identity.
        # --------------------------------------------------------------
        if manifest.mandatory_kernel.kernel_version != CANONICAL_KERNEL_VERSION:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.KERNEL_VERSION_INCOMPATIBLE,
                details=(
                    f"manifest kernel_version {manifest.mandatory_kernel.kernel_version!r} "
                    f"does not match current canonical kernel version "
                    f"{CANONICAL_KERNEL_VERSION!r}"
                ),
                manifest_id=manifest.manifest_id or None,
            )

        # --------------------------------------------------------------
        # M4 — D7 drift check 3: canonical mandatory invariant set (§12.3).
        # Semantic set identity against ggm.invariants.MANDATORY_INVARIANT_IDS;
        # the manifest is never repaired, only rejected.
        # --------------------------------------------------------------
        manifest_invariants = set(manifest.mandatory_kernel.mandatory_invariants)
        canonical_invariants = set(MANDATORY_INVARIANT_IDS)
        if manifest_invariants != canonical_invariants:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.MANIFEST_INTEGRITY_FAILURE,
                details=(
                    f"mandatory invariant drift: manifest declares "
                    f"{sorted(manifest_invariants)}, canonical set is "
                    f"{sorted(canonical_invariants)} "
                    f"(missing: {sorted(canonical_invariants - manifest_invariants)}, "
                    f"additional: {sorted(manifest_invariants - canonical_invariants)})"
                ),
                manifest_id=manifest.manifest_id or None,
            )

        # --------------------------------------------------------------
        # M5 — D7 drift check 4: resolve profile references against the
        # canonical registry (§12.4). Exact (profile_id, profile_version)
        # match; no fallback to a similarly named profile.
        # --------------------------------------------------------------
        canonical_registry = canonical_profile_registry()
        referenced: Dict[str, Any] = {}
        for ref in manifest.profiles_resolved:
            profile = lookup_profile(ref.profile_id, ref.profile_version, canonical_registry)
            if profile is None:
                return RuntimeMaterializationError(
                    error_type=RuntimeMaterializationErrorType.PROFILE_REFERENCE_NOT_FOUND,
                    details=(
                        f"profile reference {ref.profile_id}@{ref.profile_version} "
                        f"not found in the current canonical profile registry"
                    ),
                    manifest_id=manifest.manifest_id or None,
                )
            referenced[profile.profile_id] = profile

        # --------------------------------------------------------------
        # M6 — Construct filtered registry (D1): exactly the referenced
        # canonical profiles + canonical ggm.base unconditionally. No other
        # profile enters; canonical objects are referenced, never modified
        # or reconstructed. No new resolver/merge/precedence semantics.
        # --------------------------------------------------------------
        filtered_registry: Dict[str, Any] = dict(referenced)
        base = canonical_registry.get("ggm.base")
        if base is None:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.MATERIALIZATION_INTEGRITY_FAILURE,
                details="canonical profile registry does not contain ggm.base",
                manifest_id=manifest.manifest_id or None,
            )
        filtered_registry["ggm.base"] = base

        # --------------------------------------------------------------
        # M7 — D7 drift check 5: verify enabled operations against the
        # frozen P1.2 operation vocabulary (§12.5)
        # --------------------------------------------------------------
        operations: List[Operation] = []
        for op_raw in manifest.operations_enabled:
            try:
                operations.append(Operation(op_raw))
            except ValueError:
                return RuntimeMaterializationError(
                    error_type=RuntimeMaterializationErrorType.CAPABILITY_MAPPING_NOT_FOUND,
                    details=f"unknown operation in manifest.operations_enabled: {op_raw!r}",
                    manifest_id=manifest.manifest_id or None,
                )
        operations_enabled = frozenset(operations)

        # --------------------------------------------------------------
        # M8 — Build operation dependency closure (§9 map). Only machinery
        # required by enabled operations. Constructor couplings are checked
        # against the closure: if a required engine's canonical constructor
        # mechanically requires machinery outside the closure (machinery
        # belonging to a disabled operation, which the valid execution path
        # of an enabled operation cannot execute), satisfying it would
        # violate D2 structural minimality — classify and STOP per §9/§16.
        # --------------------------------------------------------------
        required_machinery: set = set()
        for op in operations_enabled:
            required_machinery.update(_OPERATION_MACHINERY[op])

        coupling_error = self._check_constructor_coupling(required_machinery, manifest)
        if coupling_error is not None:
            return coupling_error

        # --------------------------------------------------------------
        # M9 — Build capability gate (D3) from exactly
        # manifest.operations_enabled. Undeclared operation ->
        # ConsumptionError(CapabilityNotAvailable), never
        # GovernanceResult(BLOCK). This is the behavioral gate; structural
        # minimality (D2) stands in addition to it.
        # --------------------------------------------------------------
        capability_check = self._build_capability_gate(operations_enabled)

        # --------------------------------------------------------------
        # M10 — Construct the runtime. Instantiate only closure machinery,
        # in dependency order, from canonical classes.
        # --------------------------------------------------------------
        machinery: Dict[str, Any] = {}
        if "invariant_engine" in required_machinery:
            machinery["invariant_engine"] = InvariantEngine()
        if "profile_resolver" in required_machinery:
            machinery["profile_resolver"] = ProfileResolver(filtered_registry)
        if "transition_engine" in required_machinery:
            machinery["transition_engine"] = TransitionEngine(machinery["invariant_engine"])
        if "escalation_detector" in required_machinery:
            machinery["escalation_detector"] = EscalationDetector(machinery["invariant_engine"])
        if "governance_decision_engine" in required_machinery:
            # Optional constructor dependencies (post-repair): pass the
            # coupled engines when they were materialized for their own
            # enabled operations, None otherwise — never fabricate engines
            # to satisfy the constructor (§9, Repair Mandate v1 §2/§4).
            machinery["governance_decision_engine"] = GovernanceDecisionEngine(
                transition_engine=machinery.get("transition_engine"),
                escalation_detector=machinery.get("escalation_detector"),
                profile_resolver=machinery["profile_resolver"],
            )

        consumer = _MaterializedConsumer(machinery=machinery, capability_check=capability_check)

        runtime = MaterializedGGMRuntime(
            manifest=manifest,
            operations_enabled=operations_enabled,
            machinery=machinery,
            consumer=consumer,
        )

        # --------------------------------------------------------------
        # M11 — Post-construction integrity check (§8)
        # --------------------------------------------------------------
        integrity = self._post_construction_integrity(runtime, manifest, operations_enabled)
        if integrity is not None:
            return integrity

        return runtime

    # ------------------------------------------------------------------
    # M8 helper — constructor-coupling detection (§9 DECIDE / §16)
    # ------------------------------------------------------------------

    @staticmethod
    def _check_constructor_coupling(
        required_machinery: set,
        manifest: ResolvedConsumptionManifest,
    ) -> Optional[RuntimeMaterializationError]:
        """Verify, against the live canonical constructor signatures, that
        every required engine can be constructed from inside the closure.

        If GovernanceDecisionEngine (or any required engine) mechanically
        requires machinery that is NOT in the closure — i.e. machinery
        belonging only to a disabled operation — this is the
        P2.2_CONSTRUCTOR_COUPLING_BLOCKER (§9): report it, stop that
        materialization, never fabricate null engines and never silently
        broaden the architecture.
        """
        for machinery_name in sorted(required_machinery):
            required_params = _CONSTRUCTOR_PARAMS.get(machinery_name, ())

            # Deterministic verification that the frozen P2.1 map still
            # matches the live canonical constructor (D7: drift between the
            # frozen map and canonical code prevents materialization too).
            cls = _ENGINE_CLASSES[machinery_name]
            data_params = _DATA_PARAMS.get(machinery_name, ())
            sig_params = {
                name: p
                for name, p in inspect.signature(cls.__init__).parameters.items()
                if name != "self"
                and p.kind in (
                    inspect.Parameter.POSITIONAL_ONLY,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    inspect.Parameter.KEYWORD_ONLY,
                )
                and name not in data_params
            }
            live_required = {n for n, p in sig_params.items() if p.default is inspect.Parameter.empty}
            # Two-way drift check (post-repair rule, Repair Mandate v1 §4):
            # (a) every mechanically required live parameter (no default)
            #     must be recorded in the frozen map — the canonical
            #     constructor must never become MORE demanding than the map;
            # (b) every parameter the frozen map requires must still exist
            #     in the live signature — the map must never reference
            #     removed/renamed couplings. Parameters that are optional in
            #     the signature but mandatory by constructor body-guard
            #     (post-repair profile_resolver, enforced by TypeError in
            #     __init__) are recorded in the map and verified by (b).
            if not live_required.issubset(set(required_params)) or not set(required_params).issubset(set(sig_params)):
                return RuntimeMaterializationError(
                    error_type=RuntimeMaterializationErrorType.MATERIALIZATION_INTEGRITY_FAILURE,
                    details=(
                        f"canonical constructor drift: {cls.__name__}.__init__ signature "
                        f"{tuple(sig_params)} (required: {sorted(live_required)}) is "
                        f"incompatible with frozen P2.1 dependency map {required_params}"
                    ),
                    manifest_id=manifest.manifest_id or None,
                )

            missing = [p for p in required_params if p not in required_machinery]
            if missing:
                blocker = None
                if cls is GovernanceDecisionEngine:
                    blocker = {
                        "classification": CONSTRUCTOR_COUPLING_BLOCKER,
                        "exact_class": "ggm.governance.GovernanceDecisionEngine",
                        "exact_constructor_parameters": missing,
                        "why_it_forces_unrelated_machinery": (
                            "GovernanceDecisionEngine.__init__ requires live TransitionEngine "
                            "and EscalationDetector instances, but under contract v1.3 the "
                            "valid DECIDE path cannot execute either: GovernanceRequest "
                            "validation forbids requested_transitions for operation=DECIDE, "
                            "and the consumer's DECIDE mapping never passes "
                            "generated_representation. For a runtime whose enabled operations "
                            "do not include TRANSITION and/or CHECK_ESCALATION, satisfying "
                            "the constructor would instantiate machinery belonging only to "
                            "disabled operations, violating frozen D2 structural minimality."
                        ),
                        "smallest_proposed_compatibility_preserving_change": (
                            "Make transition_engine and escalation_detector optional keyword "
                            "parameters of GovernanceDecisionEngine.__init__ (default None); "
                            "decide() already skips its transition loop when "
                            "requested_transitions is None/empty and skips its escalation "
                            "branch when generated_representation is None, so a None engine "
                            "is never dereferenced on the valid DECIDE path. Existing "
                            "three-argument callers are unaffected. REQUIRES HUMAN "
                            "AUTHORIZATION — P2.2 does not modify canonical engine files."
                        ),
                    }
                return RuntimeMaterializationError(
                    error_type=RuntimeMaterializationErrorType.CAPABILITY_DEPENDENCY_MISSING,
                    details=(
                        f"{cls.__name__} constructor requires machinery outside the enabled "
                        f"operation closure: {missing} (closure: {sorted(required_machinery)}). "
                        f"Classified as {CONSTRUCTOR_COUPLING_BLOCKER}; implementation of this "
                        f"operation set is STOPPED for review per P2.2 §9/§16."
                    ),
                    manifest_id=manifest.manifest_id or None,
                    blocker=blocker,
                )
        return None

    # ------------------------------------------------------------------
    # M9 helper — capability gate (D3)
    # ------------------------------------------------------------------

    @staticmethod
    def _build_capability_gate(operations_enabled: frozenset) -> Callable[[GovernanceRequest], Optional[str]]:
        """The P1.2 capability_check hook, configured directly and
        exclusively from manifest.operations_enabled. Returns a reason
        string for any undeclared operation (which DefaultGGMConsumer maps
        to ConsumptionError(CapabilityNotAvailable) — never
        GovernanceResult(BLOCK)); returns None when the capability is
        available. Requests whose operation is not a valid Operation at all
        are left to structural validation (MalformedRequest), matching
        canonical consumer behavior."""
        def capability_check(request: GovernanceRequest) -> Optional[str]:
            op = request.operation
            if not isinstance(op, Operation):
                try:
                    op = Operation(op)
                except (ValueError, TypeError):
                    return None  # structural validation reports it
            if op not in operations_enabled:
                return (
                    f"operation {op.value} is not enabled by this runtime's manifest "
                    f"(operations_enabled: {sorted(o.value for o in operations_enabled)})"
                )
            return None

        return capability_check

    # ------------------------------------------------------------------
    # M11 helper — post-construction integrity check (§8)
    # ------------------------------------------------------------------

    @staticmethod
    def _post_construction_integrity(
        runtime: MaterializedGGMRuntime,
        manifest: ResolvedConsumptionManifest,
        operations_enabled: frozenset,
    ) -> Optional[RuntimeMaterializationError]:
        problems: List[str] = []

        # exposes exactly the enabled operation set
        if runtime.operations_enabled != operations_enabled:
            problems.append("runtime operation set differs from manifest.operations_enabled")
        if set(manifest.operations_enabled) != {op.value for op in runtime.operations_enabled}:
            problems.append("runtime operation vocabulary differs from the manifest's")

        # ggm.base present whenever profile resolution was materialized
        machinery = runtime._machinery
        resolver = machinery.get("profile_resolver")
        if resolver is not None and "ggm.base" not in resolver.registry:
            problems.append("profile resolution materialized without canonical ggm.base")

        # runtime registry contains only referenced profiles + ggm.base
        if resolver is not None:
            allowed = {p.profile_id for p in manifest.profiles_resolved} | {"ggm.base"}
            extra = set(resolver.registry.keys()) - allowed
            if extra:
                problems.append(f"runtime registry contains profiles outside the manifest closure: {sorted(extra)}")

        # canonical mandatory invariant identity retained (unmodified
        # canonical source — the runtime introduces no second kernel)
        if set(manifest.mandatory_kernel.mandatory_invariants) != set(MANDATORY_INVARIANT_IDS):
            problems.append("mandatory invariant identity not retained")

        # bound to the same manifest_id (D5)
        if runtime.manifest_id != manifest.manifest_id:
            problems.append("runtime manifest_id does not match the manifest's")

        # current canonical contract/kernel versions (D6)
        if runtime.describe()["contract_version"] != CONTRACT_VERSION:
            problems.append("runtime contract version is not the current CONTRACT_VERSION")
        if runtime.describe()["runtime_version"] != RUNTIME_VERSION:
            problems.append("runtime version is not the current canonical RUNTIME_VERSION")
        if runtime.describe()["kernel_version"] != CANONICAL_KERNEL_VERSION:
            problems.append("runtime kernel version is not the current CANONICAL_KERNEL_VERSION")

        # D8: no ClaimStore, ever
        if any("claim_store" in key or "persistence" in key for key in machinery):
            problems.append("persistence machinery materialized — D8 violation")

        if problems:
            return RuntimeMaterializationError(
                error_type=RuntimeMaterializationErrorType.MATERIALIZATION_INTEGRITY_FAILURE,
                details="; ".join(problems),
                manifest_id=manifest.manifest_id or None,
            )
        return None
