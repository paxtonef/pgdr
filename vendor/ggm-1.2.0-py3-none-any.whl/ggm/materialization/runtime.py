"""
ggm.materialization.runtime — MaterializedGGMRuntime (P2.2 Implementation
Mandate v1 §10-§11).

One generic runtime object. There are no consumer-specific runtime classes
(§5), no RuntimeDescriptor as a second persisted object (§5/§11), and no
runtime_id (D5/§11): manifest.manifest_id is the runtime-configuration
identity.

Runner-facing use is exactly the existing GGMConsumer contract:

    result = runtime.consumer.evaluate(request)

The runner never sees which internal canonical engines were materialized;
engines are held privately and are not public runner-facing API (§10).
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from ggm.consumption.types import ResolvedConsumptionManifest, ResolvedProfileRef, MandatoryKernel
from ggm.contract.types import CONTRACT_VERSION, RUNTIME_VERSION
from ggm.contract.interface import DefaultGGMConsumer

__all__ = ["MaterializedGGMRuntime"]


class _MaterializedConsumer(DefaultGGMConsumer):
    """GGMConsumer-compatible evaluation surface for a materialized runtime.

    Subclasses DefaultGGMConsumer to reuse its canonical operation-mapping
    code (_decide / _transition / _check_escalation) verbatim — P2.2
    introduces no second implementation of the contract §7 mappings, so
    governance equivalence (§15) holds by construction for every
    materialized operation.

    The one deliberate difference is construction: DefaultGGMConsumer's own
    __init__ always instantiates the full historical GGM (all engines), which
    frozen D2 forbids for a bounded runtime. This __init__ therefore wires
    only the machinery the RuntimeMaterializer actually materialized for the
    enabled operation set. Machinery belonging to a disabled operation is
    never instantiated and never referenced here; the capability gate
    (constructed from manifest.operations_enabled, §9/M9) rejects any request
    for a disabled operation with ConsumptionError(CapabilityNotAvailable)
    before operation dispatch, so the unset attributes are unreachable on
    every legal evaluation path.
    """

    # Machinery-name -> DefaultGGMConsumer attribute-name binding. This is a
    # wiring map only: it introduces no behavior and no new semantics, it
    # binds the materializer's machinery keys onto the exact attribute names
    # the canonical P1.2 operation handlers (_decide/_transition/
    # _check_escalation) already read.
    _ATTR_BINDING = {
        "invariant_engine": "invariant",
        "profile_resolver": "resolver",
        "transition_engine": "transition",
        "escalation_detector": "escalation",
        "governance_decision_engine": "decider",
    }

    def __init__(
        self,
        *,
        machinery: Dict[str, Any],
        capability_check,
    ):
        # Intentionally does NOT call super().__init__(): the superclass
        # constructor would instantiate the complete GGM engine set, which D2
        # structural minimality prohibits for a bounded runtime.
        for key, engine in machinery.items():
            setattr(self, self._ATTR_BINDING[key], engine)
        self._capability_check = capability_check


class MaterializedGGMRuntime:
    """The single generic P2.2 runtime object (§10).

    Bound at materialization time to:
      - an immutable reference to the ResolvedConsumptionManifest it was
        materialized from (never mutated by the materializer or the runtime);
      - the exact enabled-operation set declared by the manifest;
      - only the canonical machinery required by those operations;
      - a GGMConsumer-compatible evaluation surface.

    Canonical engines are NOT exposed as public runner-facing API. The
    private _machinery map exists for materialization-time integrity checks
    (M11) and structural-minimality inspection (§13) only.
    """

    def __init__(
        self,
        *,
        manifest: ResolvedConsumptionManifest,
        operations_enabled: frozenset,
        machinery: Dict[str, Any],
        consumer: _MaterializedConsumer,
    ):
        self._manifest = manifest
        self._operations_enabled = frozenset(operations_enabled)
        self._machinery = dict(machinery)
        self._consumer = consumer

    # ------------------------------------------------------------------
    # §10 minimum conceptual surface
    # ------------------------------------------------------------------

    @property
    def manifest(self) -> ResolvedConsumptionManifest:
        """The manifest this runtime was materialized from. Read-through
        reference — the runtime never mutates it (T23)."""
        return self._manifest

    @property
    def manifest_id(self) -> str:
        """D5: manifest.manifest_id IS the runtime-configuration identity.
        There is no runtime_id anywhere in P2.2."""
        return self._manifest.manifest_id

    @property
    def operations_enabled(self) -> frozenset:
        """The enabled operation set (Operation members), exactly as
        declared by manifest.operations_enabled."""
        return self._operations_enabled

    @property
    def profiles_resolved(self) -> List[ResolvedProfileRef]:
        """Read-through of manifest.profiles_resolved (not a copy of
        governance semantics — the resolved references themselves)."""
        return self._manifest.profiles_resolved

    @property
    def mandatory_kernel(self) -> MandatoryKernel:
        """D4: the declarative mandatory-floor representation, read through
        from the manifest. Executable enforcement remains canonical GGM
        machinery (InvariantEngine), not a second MandatoryKernel class."""
        return self._manifest.mandatory_kernel

    @property
    def consumer(self) -> _MaterializedConsumer:
        """The GGMConsumer-compatible facade (§10). Runner-facing use:
        runtime.consumer.evaluate(request)."""
        return self._consumer

    # ------------------------------------------------------------------
    # §11 runtime view / identity — read-only, derived, never persisted
    # ------------------------------------------------------------------

    def describe(self) -> Dict[str, Any]:
        """Read-only runtime-description view (§11), derived on each call
        from the manifest plus current canonical version information. Not a
        persisted object, not new identity state, no runtime_id — these are
        views/read-through values, not duplicated authorities."""
        return {
            "manifest_id": self._manifest.manifest_id,
            "contract_version": CONTRACT_VERSION,
            "runtime_version": RUNTIME_VERSION,
            "kernel_version": self._manifest.mandatory_kernel.kernel_version,
            "operations_enabled": sorted(op.value for op in self._operations_enabled),
            "profiles_resolved": [p.to_dict() for p in self._manifest.profiles_resolved],
            "capability_profile_id": self._manifest.capability_profile_id,
            "capability_profile_version": self._manifest.capability_profile_version,
            "deployment_profile_id": self._manifest.deployment_profile_id,
            "deployment_profile_version": self._manifest.deployment_profile_version,
        }

    # ------------------------------------------------------------------
    # Structural-minimality inspection (§13 / M11) — not runner-facing
    # ------------------------------------------------------------------

    def machinery_keys(self) -> Tuple[str, ...]:
        """Names of the machinery components actually instantiated for this
        runtime (e.g. 'invariant_engine', 'profile_resolver',
        'transition_engine', 'escalation_detector',
        'governance_decision_engine'). Exists so D2 structural minimality
        (§13) and the M11 integrity check can be proven mechanically;
        returns names only, never the engines themselves."""
        return tuple(sorted(self._machinery.keys()))
