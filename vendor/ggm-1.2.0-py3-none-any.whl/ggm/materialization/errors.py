"""
ggm.materialization.errors — RuntimeMaterializationError, the P2.2 Runtime
Materialization layer's failure channel (P2.2 Implementation Mandate v1 §6).

A RuntimeMaterializationError is a *materialization-time* failure: the
resolved manifest could not be turned into a bounded runtime. It is
structurally disjoint from every pre-existing outcome/error channel:

  GovernanceResult            == governance evaluated a request (P1.2 §4).
  ConsumptionError            == governance could not be delivered for a
                                 request at consumption time (P1.2 §5).
  ConsumptionResolutionError  == a three-axis declaration could not be
                                 resolved into a manifest (P1.3 §12).
  RuntimeMaterializationError == a resolved manifest could not be
                                 materialized into a runtime (P2.2 §6).

Materialization happens after resolution and before any consumption: no
governance outcome may be used for a materialization failure, and no
materialization failure is ever reported as a GovernanceResult(BLOCK).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional

__all__ = [
    "RuntimeMaterializationErrorType",
    "RuntimeMaterializationError",
    "CONSTRUCTOR_COUPLING_BLOCKER",
]


# P2.2 §16: classification tag reported when a canonical engine constructor
# mechanically requires machinery that the valid execution path of an enabled
# operation cannot execute, and that machinery belongs to a *disabled*
# operation — satisfying the constructor would violate frozen D2 structural
# minimality. Reported, never silently worked around; no canonical engine
# file is modified by P2.2.
CONSTRUCTOR_COUPLING_BLOCKER = "P2.2_CONSTRUCTOR_COUPLING_BLOCKER"


class RuntimeMaterializationErrorType(str, Enum):
    """Bounded materialization failure vocabulary (P2.2 §6). Exhaustive for
    P2.2 — every materialization failure is exactly one of these."""
    INVALID_MANIFEST = "INVALID_MANIFEST"
    MANIFEST_INTEGRITY_FAILURE = "MANIFEST_INTEGRITY_FAILURE"
    UNSUPPORTED_MANIFEST_VERSION = "UNSUPPORTED_MANIFEST_VERSION"
    CONTRACT_VERSION_INCOMPATIBLE = "CONTRACT_VERSION_INCOMPATIBLE"
    KERNEL_VERSION_INCOMPATIBLE = "KERNEL_VERSION_INCOMPATIBLE"
    PROFILE_REFERENCE_NOT_FOUND = "PROFILE_REFERENCE_NOT_FOUND"
    CAPABILITY_MAPPING_NOT_FOUND = "CAPABILITY_MAPPING_NOT_FOUND"
    CAPABILITY_DEPENDENCY_MISSING = "CAPABILITY_DEPENDENCY_MISSING"
    MATERIALIZATION_INTEGRITY_FAILURE = "MATERIALIZATION_INTEGRITY_FAILURE"


@dataclass
class RuntimeMaterializationError:
    """P2.2 §6. Not a GovernanceResult, ConsumptionError, or
    ConsumptionResolutionError — a structurally distinct dataclass returned
    by RuntimeMaterializer.materialize() instead of a runtime.

    blocker: populated only when the failure is a classified
    P2.2_CONSTRUCTOR_COUPLING_BLOCKER report (§9 DECIDE / §16), carrying the
    exact class, exact constructor parameter(s), why the coupling forces
    unrelated machinery, and the smallest proposed compatibility-preserving
    change. Human authorization is required before any such canonical-file
    change; P2.2 itself never performs it.
    """
    error_type: RuntimeMaterializationErrorType = RuntimeMaterializationErrorType.INVALID_MANIFEST
    details: str = ""
    manifest_id: Optional[str] = None
    blocker: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_type": self.error_type.value,
            "details": self.details,
            "manifest_id": self.manifest_id,
            "blocker": self.blocker,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RuntimeMaterializationError":
        return cls(
            error_type=RuntimeMaterializationErrorType(d.get("error_type", "INVALID_MANIFEST")),
            details=d.get("details", ""),
            manifest_id=d.get("manifest_id"),
            blocker=d.get("blocker"),
        )
