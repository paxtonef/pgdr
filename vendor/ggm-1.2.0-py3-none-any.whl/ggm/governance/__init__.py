"""ggm.governance — TransitionEngine, EscalationDetector, GovernanceDecisionEngine (mechanical extraction from ggm_core.py)."""

from __future__ import annotations

import uuid
import json
import copy
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, List, Dict, Tuple, Set
from pathlib import Path


from ggm.model import (
    OriginType, AuthorityLevel, RiskLevel, ClaimFamily,
    TransitionMode, DecisionType, TransitionEvent, GovernanceDecision,
)
from ggm.invariants import GGMInvariantViolation, InvariantEngine
from ggm.profiles import EffectiveProfile, ProfileResolver

# =============================================================================
# TRANSITION ENGINE
# =============================================================================

class TransitionEngine:
    """
    Evaluates transitions using a provided EffectiveProfile (no double resolution).
    """

    def __init__(self, invariant_engine: InvariantEngine):
        self.invariant = invariant_engine
        self.events: List[TransitionEvent] = []

    def evaluate(
        self,
        obj: GovernedObject,
        dimension: str,
        requested_state: str,
        effective_profile: EffectiveProfile,
        trigger_type: str = "manual",
        actor_id: Optional[str] = None,
        evidence: Optional[List[Dict[str, Any]]] = None,
        provided_events: Optional[List[str]] = None,
        corroborating_claims: Optional[List[Any]] = None,
    ) -> Tuple[str, TransitionEvent]:
        """
        Evaluate transition using pre-resolved effective profile.

        corroborating_claims (GGM-I08 repair): zero or more claims offered
        as corroboration for the object being transitioned, consulted only
        by the `independent_confirmation` requirement branch of
        _check_requirements(). Defaults to none, matching every existing
        caller that predates this parameter.
        """
        current_state = self._get_current_state(obj, dimension)
        evidence = evidence or []
        provided_events = provided_events or []
        corroborating_claims = corroborating_claims or []

        # 1. Hard invariant check
        try:
            self.invariant.check_transition(obj, dimension, requested_state)
        except GGMInvariantViolation as e:
            event = TransitionEvent(
                object_id=obj.id,
                dimension=dimension,
                previous_state=current_state,
                requested_state=requested_state,
                resulting_state=current_state,
                trigger_type=trigger_type,
                actor_id=actor_id,
                evidence=evidence,
                rules_applied=["hard_invariant"],
                decision="blocked",
            )
            self.events.append(event)
            return current_state, event

        # 2. Find applicable rule in effective profile
        rule_key = f"{dimension}:{current_state}->{requested_state}"
        transition_rules = effective_profile.effective_rules.get("transitions", {})
        rule_def = transition_rules.get(rule_key)

        if rule_def is None:
            # Fallback policy — fail-closed for consequential governance dimensions.
            # authority and operational transitions with NO explicit rule must never
            # resolve to ALLOW. We deliberately do NOT reuse the profile's
            # consequential_execution value here: it may be GATED with zero attached
            # requirements (a synthetic rule_def has no "requirements" key), which
            # degenerates to an automatic allow since nothing is left to be missing.
            # Absence of authorization, not risk level or an under-specified profile
            # value, is what must gate these dimensions.
            if dimension in ["authority", "operational"]:
                mode = TransitionMode.ESCALATE
            else:
                mode = TransitionMode.ALLOW
            rule_def = {"mode": mode.value}
        else:
            mode = TransitionMode(rule_def.get("mode", "ALLOW"))

        # 3. Check typed requirements
        reqs = rule_def.get("requirements", {})
        missing_reqs = self._check_requirements(obj, reqs, evidence, provided_events, corroborating_claims)

        # 4. Apply mode
        if mode == TransitionMode.FORBID:
            result_state = current_state
            decision = "blocked"
            reasons = ["Transition forbidden by profile"] + missing_reqs
        elif mode == TransitionMode.GATED:
            if missing_reqs:
                result_state = current_state
                decision = "blocked"
                reasons = ["Gated transition: requirements not met"] + missing_reqs
            else:
                result_state = requested_state
                decision = "allowed"
                reasons = ["Gated transition: requirements met"]
        elif mode == TransitionMode.ESCALATE:
            result_state = current_state
            decision = "escalated"
            reasons = ["Transition requires escalation"] + missing_reqs
        else:  # ALLOW
            result_state = requested_state
            decision = "allowed"
            reasons = ["Transition allowed"]

        event = TransitionEvent(
            object_id=obj.id,
            dimension=dimension,
            previous_state=current_state,
            requested_state=requested_state,
            resulting_state=result_state,
            trigger_type=trigger_type,
            actor_id=actor_id,
            evidence=evidence,
            rules_applied=[rule_key] if rule_key in transition_rules else ["fallback"],
            decision=decision,
        )
        self.events.append(event)
        return result_state, event

    def _check_requirements(
        self,
        obj: GovernedObject,
        reqs: Dict[str, List[Dict[str, Any]]],
        evidence: List[Dict[str, Any]],
        provided_events: List[str],
        corroborating_claims: Optional[List[Any]] = None,
    ) -> List[str]:
        """Typed requirement validation."""
        missing: List[str] = []
        corroborating_claims = corroborating_claims or []

        # Evidence requirements
        for req in reqs.get("evidence", []):
            req_type = req.get("type")
            min_count = req.get("min_count", 1)
            matching = [e for e in evidence if req_type is None or e.get("type") == req_type]
            if len(matching) < min_count:
                missing.append(f"evidence: need {min_count} of type '{req_type or 'any'}', got {len(matching)}")

        # Verification requirements
        for req in reqs.get("verification", []):
            method = req.get("method", "any")
            # Must be marked verified
            if not obj.epistemic.properties.get("verified", False):
                missing.append("verification: claim not marked verified")
                continue
            # Self-verification guard
            if obj.origin.origin_type == OriginType.LLM and method == "external":
                missing.append("verification: LLM cannot self-verify (external method required)")
            # Validator match
            validator_id = req.get("validator_id")
            if validator_id and obj.authority.authority_id != validator_id:
                missing.append(f"verification: validator '{validator_id}' mismatch")

        # Authority requirements
        for req in reqs.get("authorities", []):
            required_level = AuthorityLevel(req["min_level"]) if req.get("min_level") else AuthorityLevel.NONE
            required_id = req.get("authority_id")
            # Check level (explicit ordering for permission checks only)
            level_order = {
                AuthorityLevel.NONE: 0, AuthorityLevel.ADVISORY: 1,
                AuthorityLevel.DELEGATED: 2, AuthorityLevel.DOMAIN_AUTHORIZED: 3,
                AuthorityLevel.GOVERNANCE_AUTHORIZED: 4,
            }
            if level_order.get(obj.authority.level, -1) < level_order.get(required_level, 999):
                missing.append(f"authority: need level >= {required_level.value}, got {obj.authority.level.value}")
            if required_id and obj.authority.authority_id != required_id:
                missing.append(f"authority: need id '{required_id}', got '{obj.authority.authority_id}'")

        # Event requirements
        for req in reqs.get("events", []):
            ev_id = req if isinstance(req, str) else req.get("event_id")
            if ev_id and ev_id not in provided_events:
                missing.append(f"event: '{ev_id}' required but not provided")

        # Independent-confirmation requirements (GGM-I08 repair).
        # verify_independent_confirmation(claim, other_claims) returns True
        # if *at least one* of other_claims is independent of claim; called
        # once per candidate (rather than once with the full list) to get an
        # actual count of independently-confirming claims comparable to
        # min_count, without changing the primitive's own semantics.
        for req in reqs.get("independent_confirmation", []):
            min_count = req.get("min_count", 1)
            independent_count = sum(
                1 for other in corroborating_claims
                if InvariantEngine.verify_independent_confirmation(obj, [other])
            )
            if independent_count < min_count:
                missing.append(
                    f"independent_confirmation: need {min_count} independently "
                    f"confirming claim(s), got {independent_count}"
                )

        return missing

    @staticmethod
    def _get_current_state(obj: GovernedObject, dimension: str) -> str:
        if dimension == "epistemic":
            return obj.epistemic.status.value
        elif dimension == "authority":
            return obj.authority.level.value
        elif dimension == "lifecycle":
            return obj.lifecycle.status.value
        elif dimension == "operational":
            if obj.permissions.execute:
                return "EXECUTE"
            elif obj.permissions.implement:
                return "IMPLEMENT"
            elif obj.permissions.plan:
                return "PLAN"
            elif obj.permissions.recommend:
                return "RECOMMEND"
            elif obj.permissions.explore:
                return "EXPLORE"
            return "NONE"
        return "UNKNOWN"


# =============================================================================
# ESCALATION DETECTOR
# =============================================================================

class EscalationDetector:
    def __init__(self, invariant_engine: InvariantEngine):
        self.invariant = invariant_engine

    def detect(self, source: GovernedObject, generated: GovernedObject) -> Dict[str, Any]:
        violation = self.invariant.check_narrative_escalation(source, generated)

        # Additional: expressed certainty vs epistemic properties
        expressed = generated.classification.expressed_certainty
        certainty_mismatch = False
        if expressed and expressed.lower() in {"certain", "established", "proven", "definite", "absolute"}:
            if not generated.epistemic.properties.get("verified", False):
                certainty_mismatch = True

        family_escalation = False
        if ClaimFamily.HYPOTHETICAL in source.classification.families:
            escalatory = {ClaimFamily.FACTUAL, ClaimFamily.CAUSAL, ClaimFamily.NORMATIVE, ClaimFamily.DECISIONAL, ClaimFamily.OPERATIONAL}
            if any(f in escalatory for f in generated.classification.families):
                family_escalation = True

        detected = bool(violation) or certainty_mismatch or family_escalation

        return {
            "detected": detected,
            "narrative_violation": violation,
            "certainty_mismatch": certainty_mismatch,
            "family_escalation": family_escalation,
            "source_epistemic_status": source.epistemic.status.value,
            "generated_epistemic_status": generated.epistemic.status.value,
            "source_authority": source.authority.level.value,
            "generated_authority": generated.authority.level.value,
        }


# =============================================================================
# GOVERNANCE DECISION ENGINE
# =============================================================================

class GovernanceDecisionEngine:
    def __init__(
        self,
        transition_engine: Optional[TransitionEngine] = None,
        escalation_detector: Optional[EscalationDetector] = None,
        profile_resolver: Optional[ProfileResolver] = None,
    ):
        # P2.2 DECIDE constructor-coupling repair
        # (docs/P2.2_DECIDE_Constructor_Coupling_Investigation_v1.md §7,
        # Repair Implementation Mandate v1 §2):
        # transition_engine and escalation_detector are used only by the
        # requested_transitions / generated_representation branches of
        # decide(), which the contract's DECIDE operation cannot reach
        # (contract v1.3: requested_transitions is TRANSITION-only and
        # GovernanceRequest carries no generated-representation channel).
        # They are therefore optional constructor dependencies; both gated
        # branches fail fast with a deterministic dependency error if
        # entered without their engine (see below) — never an accidental
        # AttributeError, never a silent skip.
        # profile_resolver remains mandatory: resolver.resolve() is
        # executed unconditionally on every decide() call.
        # Existing three-positional-argument callers are unaffected.
        if profile_resolver is None:
            raise TypeError(
                "GovernanceDecisionEngine requires a profile_resolver: "
                "profile resolution is executed unconditionally by decide()"
            )
        self.transition = transition_engine
        self.escalation = escalation_detector
        self.resolver = profile_resolver
        self.decisions: List[GovernanceDecision] = []

    def decide(
        self,
        obj: GovernedObject,
        requested_transitions: Optional[List[Tuple[str, str]]] = None,
        generated_representation: Optional[GovernedObject] = None,
        context: Optional[Dict[str, str]] = None,
        evidence: Optional[List[Dict[str, Any]]] = None,
        provided_events: Optional[List[str]] = None,
    ) -> GovernanceDecision:
        context = context or {}
        evidence = evidence or []
        provided_events = provided_events or []
        reasons: List[str] = []
        rules_applied: List[str] = []
        decision = DecisionType.ALLOW
        repair_instruction: Optional[str] = None

        # SINGLE profile resolution
        effective = self.resolver.resolve(obj, context)
        obj.effective_profile_id = effective.resolution_id

        # Evaluate requested transitions with the SAME effective profile
        if requested_transitions:
            # Fail fast (deterministic engine construction/use error, not a
            # governance outcome): this branch requires a transition engine.
            if self.transition is None:
                raise TypeError(
                    "GovernanceDecisionEngine: requested_transitions require a "
                    "transition_engine; this engine was constructed without one"
                )
            for dim, req_state in requested_transitions:
                result_state, event = self.transition.evaluate(
                    obj, dim, req_state,
                    effective_profile=effective,
                    evidence=evidence,
                    provided_events=provided_events,
                )
                rules_applied.extend(event.rules_applied)
                if event.decision == "blocked":
                    reasons.append(f"Transition {dim}->{req_state} blocked")
                    decision = DecisionType.BLOCK
                elif event.decision == "escalated":
                    reasons.append(f"Transition {dim}->{req_state} escalated")
                    if decision not in [DecisionType.BLOCK]:
                        decision = DecisionType.ESCALATE

        # Check escalation if generated representation provided
        if generated_representation:
            # Fail fast (deterministic engine construction/use error, not a
            # governance outcome): this branch requires an escalation detector.
            if self.escalation is None:
                raise TypeError(
                    "GovernanceDecisionEngine: generated_representation requires an "
                    "escalation_detector; this engine was constructed without one"
                )
            esc = self.escalation.detect(obj, generated_representation)
            if esc["detected"]:
                reasons.append(f"Narrative escalation detected: {esc['narrative_violation'] or 'certainty/family mismatch'}")
                if decision == DecisionType.ALLOW:
                    if esc["certainty_mismatch"] or esc["family_escalation"]:
                        decision = DecisionType.REPAIR
                        repair_instruction = self._generate_repair(obj, generated_representation, esc)
                    else:
                        decision = DecisionType.BLOCK

        # Risk-based override for operational permissions without sufficient authority
        if obj.risk.level in [RiskLevel.R2, RiskLevel.R3]:
            if obj.permissions.execute or obj.permissions.implement:
                if obj.authority.level in [AuthorityLevel.NONE, AuthorityLevel.ADVISORY]:
                    if decision == DecisionType.ALLOW:
                        decision = DecisionType.ESCALATE
                        reasons.append(f"R{obj.risk.level.value[-1]} operational action requires stronger authority")

        # Fallback: no profile + consequential = block
        if not effective.profiles_applied and obj.risk.level in [RiskLevel.R2, RiskLevel.R3]:
            if any([obj.permissions.execute, obj.permissions.implement, obj.permissions.plan]):
                decision = DecisionType.BLOCK
                reasons.append("No profile resolved for consequential operation — fallback BLOCK")

        gov_decision = GovernanceDecision(
            object_id=obj.id,
            decision=decision,
            reasons=reasons,
            rules_applied=rules_applied,
            effective_permissions=copy.deepcopy(obj.permissions),
            repair_instruction=repair_instruction,
            effective_profile_id=effective.resolution_id,
        )
        self.decisions.append(gov_decision)
        return gov_decision

    @staticmethod
    def _generate_repair(source: GovernedObject, generated: GovernedObject, escalation: Dict[str, Any]) -> str:
        repairs = []
        if escalation.get("certainty_mismatch"):
            repairs.append("Reduce expressed certainty to match epistemic properties")
        if escalation.get("family_escalation"):
            if ClaimFamily.HYPOTHETICAL in source.classification.families:
                repairs.append("Restore hypothetical framing (e.g., 'may', 'might', 'could')")
        if escalation.get("narrative_violation"):
            repairs.append("Preserve original epistemic properties and authority in output")
        return " | ".join(repairs) if repairs else "Review generated representation against governed source"
