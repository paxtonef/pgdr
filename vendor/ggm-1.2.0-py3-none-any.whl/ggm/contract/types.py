"""
ggm.contract.types — GGM Consumer Contract v1.2 request/result types.

Implements the frozen Consumer Contract's data surface (GGM_Consumer_Contract_v1.2
§3, §4). This module reuses the existing GGM vocabulary (DecisionType, Permissions,
TransitionEvent, etc. from ggm.model) rather than redefining it — per contract §9,
vocabulary changes are contract-version changes, and P1.2 does not change the
contract version.

No governance semantics live here: this module only defines the shapes that
cross the consumer boundary and their structural (not semantic) validation.
Structural validation checks contract-shape compliance (required fields present,
fields scoped to the correct operation) — it never evaluates governance and
never decides ALLOW/BLOCK/etc.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from ggm.model import DecisionType

__all__ = [
    "CONTRACT_VERSION",
    "RUNTIME_VERSION",
    "Operation",
    "TransitionAsk",
    "EvidenceRef",
    "ProfileTrace",
    "GovernanceRequest",
    "GovernanceResult",
]

# Consumer Contract version this module implements. Per contract §9,
# vocabulary/shape changes are contract-version changes. Bumped from "1.2"
# to "1.3" by the GGM-I08 repair (docs/GGM-I08_Repair_Definition_v1.md
# §6.3): GovernanceRequest's public shape gained `corroborating_claims`.
# The field is optional and existing consumers remain behaviorally
# unaffected outside the two transitions this repair specifically governs.
CONTRACT_VERSION = "1.3"

# Identifies the GGM engine implementation actually evaluating requests.
# Tracks the ggm/ package version established at P1.1 (formerly "GGM Core v1.1").
RUNTIME_VERSION = "ggm/1.1"


class Operation(str, Enum):
    """The three operations defined by the frozen contract (§3). Exhaustive —
    the frozen contract defines exactly these three; this enum must not gain
    a fourth value without a contract-version change."""
    DECIDE = "DECIDE"
    TRANSITION = "TRANSITION"
    CHECK_ESCALATION = "CHECK_ESCALATION"


@dataclass
class TransitionAsk:
    """A single requested transition (contract §3). Maps 1:1 onto the
    (dimension, requested_state) pair already accepted by
    TransitionEngine.evaluate() and GovernanceDecisionEngine.decide()."""
    dimension: str = ""
    to_state: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"dimension": self.dimension, "to_state": self.to_state}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TransitionAsk":
        return cls(dimension=d.get("dimension", ""), to_state=d.get("to_state", ""))


@dataclass
class EvidenceRef:
    """A reference to evidence (contract §3). Serializes to the same
    `{"type": ..., ...}` dict shape already consumed by
    TransitionEngine._check_requirements() — no new evidence model."""
    type: str = ""
    ref: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"type": self.type}
        if self.ref is not None:
            d["ref"] = self.ref
        d.update(self.details)
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EvidenceRef":
        known = {"type", "ref"}
        return cls(
            type=d.get("type", ""),
            ref=d.get("ref"),
            details={k: v for k, v in d.items() if k not in known},
        )


@dataclass
class ProfileTrace:
    """Audit trace of profile resolution (contract §4, §10 G6). Field names
    map 1:1 onto ggm.profiles.EffectiveProfile's own fields — this is a
    read-through of that existing structure, not a new one."""
    profiles_applied: List[str] = field(default_factory=list)
    resolution_id: str = ""
    conflicts: List[str] = field(default_factory=list)
    relaxations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "profiles_applied": self.profiles_applied,
            "resolution_id": self.resolution_id,
            "conflicts": self.conflicts,
            "relaxations": self.relaxations,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ProfileTrace":
        return cls(
            profiles_applied=d.get("profiles_applied", []),
            resolution_id=d.get("resolution_id", ""),
            conflicts=d.get("conflicts", []),
            relaxations=d.get("relaxations", []),
        )


@dataclass
class GovernanceRequest:
    """Contract §3. `object` and `source_object` carry serialized governed
    objects (see ggm.contract.serialization) — never live GovernedObject
    instances, keeping the contract boundary a plain-data surface."""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object: Optional[Dict[str, Any]] = None
    operation: Optional[Operation] = None
    context: Dict[str, str] = field(default_factory=dict)
    requested_transitions: List[TransitionAsk] = field(default_factory=list)
    evidence: Optional[List[EvidenceRef]] = None
    source_object: Optional[Dict[str, Any]] = None
    # GGM-I08 repair (contract v1.3): zero or more serialized governed
    # claims carrying corroborating evidence for independent-confirmation
    # checking. Same serialized shape as `object`/`source_object` (dispatched
    # through ggm.contract.serialization.deserialize_governed_object).
    # Only meaningful for operation=TRANSITION (see validate()); a consumer
    # who omits it is unaffected outside the two specific transitions this
    # repair governs.
    corroborating_claims: Optional[List[Dict[str, Any]]] = None

    def validate(self) -> List[str]:
        """Structural (contract-shape) validation only — never evaluates
        governance. Returns a list of problems; empty list means the request
        is structurally well-formed enough to attempt evaluation."""
        problems: List[str] = []

        if not self.request_id:
            problems.append("request_id is required")
        else:
            try:
                uuid.UUID(str(self.request_id))
            except (ValueError, AttributeError, TypeError):
                problems.append("request_id must be a valid UUID")

        if self.operation is None:
            problems.append("operation is required")
        elif not isinstance(self.operation, Operation):
            try:
                Operation(self.operation)
            except ValueError:
                problems.append(f"operation must be one of {[o.value for o in Operation]}")

        if self.object is None:
            problems.append("object is required")
        elif not isinstance(self.object, dict):
            problems.append("object must be a serialized governed object (dict)")

        if not isinstance(self.context, dict):
            problems.append("context must be a map<string,string>")

        op = self.operation if isinstance(self.operation, Operation) else None

        if self.requested_transitions and op != Operation.TRANSITION:
            problems.append("requested_transitions is only valid for operation=TRANSITION")
        if op == Operation.TRANSITION and not self.requested_transitions:
            problems.append("requested_transitions is required for operation=TRANSITION")
        if op == Operation.TRANSITION:
            for i, ta in enumerate(self.requested_transitions):
                if not ta.dimension:
                    problems.append(f"requested_transitions[{i}].dimension is required")
                if not ta.to_state:
                    problems.append(f"requested_transitions[{i}].to_state is required")

        if self.source_object is not None and op != Operation.CHECK_ESCALATION:
            problems.append("source_object is only valid for operation=CHECK_ESCALATION")
        if op == Operation.CHECK_ESCALATION and self.source_object is None:
            problems.append("source_object is required for operation=CHECK_ESCALATION")
        if self.source_object is not None and not isinstance(self.source_object, dict):
            problems.append("source_object must be a serialized governed object (dict)")

        if self.corroborating_claims is not None:
            if op != Operation.TRANSITION:
                problems.append("corroborating_claims is only valid for operation=TRANSITION")
            elif not isinstance(self.corroborating_claims, list):
                problems.append("corroborating_claims must be a list")
            else:
                for i, cc in enumerate(self.corroborating_claims):
                    if not isinstance(cc, dict):
                        problems.append(f"corroborating_claims[{i}] must be a serialized governed object (dict)")

        return problems

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "object": self.object,
            "operation": self.operation.value if isinstance(self.operation, Operation) else self.operation,
            "context": self.context,
            "requested_transitions": [ta.to_dict() for ta in self.requested_transitions],
            "evidence": [e.to_dict() for e in self.evidence] if self.evidence is not None else None,
            "source_object": self.source_object,
            "corroborating_claims": self.corroborating_claims,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernanceRequest":
        op_raw = d.get("operation")
        try:
            operation = Operation(op_raw) if op_raw is not None else None
        except ValueError:
            operation = op_raw  # preserved as-is; validate() will flag it
        evidence_raw = d.get("evidence")
        return cls(
            request_id=d.get("request_id", str(uuid.uuid4())),
            object=d.get("object"),
            operation=operation,
            context=d.get("context", {}),
            requested_transitions=[TransitionAsk.from_dict(t) for t in d.get("requested_transitions", [])],
            evidence=[EvidenceRef.from_dict(e) for e in evidence_raw] if evidence_raw is not None else None,
            source_object=d.get("source_object"),
            corroborating_claims=d.get("corroborating_claims"),
        )


@dataclass
class GovernanceResult:
    """Contract §4. Exists only when governance actually evaluated the
    request (§4 critical invariant) — constructed exclusively by the
    consumer interface after a successful engine evaluation, never for
    undeliverable-governance situations (those are ConsumptionError, §5)."""
    request_id: str = ""
    outcome: DecisionType = DecisionType.BLOCK
    reasons: List[str] = field(default_factory=list)
    rules_applied: List[str] = field(default_factory=list)
    effective_permissions: Dict[str, Any] = field(default_factory=dict)
    repair_instruction: Optional[str] = None
    escalation_target: Optional[str] = None
    transition_event: Optional[Dict[str, Any]] = None
    profile_trace: ProfileTrace = field(default_factory=ProfileTrace)
    runtime_version: str = RUNTIME_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "outcome": self.outcome.value,
            "reasons": self.reasons,
            "rules_applied": self.rules_applied,
            "effective_permissions": self.effective_permissions,
            "repair_instruction": self.repair_instruction,
            "escalation_target": self.escalation_target,
            "transition_event": self.transition_event,
            "profile_trace": self.profile_trace.to_dict(),
            "runtime_version": self.runtime_version,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernanceResult":
        return cls(
            request_id=d.get("request_id", ""),
            outcome=DecisionType(d.get("outcome", "BLOCK")),
            reasons=d.get("reasons", []),
            rules_applied=d.get("rules_applied", []),
            effective_permissions=d.get("effective_permissions", {}),
            repair_instruction=d.get("repair_instruction"),
            escalation_target=d.get("escalation_target"),
            transition_event=d.get("transition_event"),
            profile_trace=ProfileTrace.from_dict(d.get("profile_trace", {})),
            runtime_version=d.get("runtime_version", RUNTIME_VERSION),
        )
