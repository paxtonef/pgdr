"""
ggm.consumption.serialization — ResolvedConsumptionManifest (de)serialization
with structural validation (§6 R8, §13).

ResolvedConsumptionManifest.from_dict() (in ggm.consumption.types) is a
permissive constructor — like every other from_dict() in this codebase, it
fills missing keys with defaults rather than raising. That is the right
behavior for from_dict() itself (consistent with e.g.
ggm.model.GovernedObject.from_dict()), but it means from_dict() alone cannot
express "this serialized manifest is malformed" (§14 T26) — a dict missing
its `governance`/`capability`/`deployment` sections would silently become an
empty-but-well-formed manifest instead of being rejected.

deserialize_manifest() below adds the missing structural check in front of
from_dict(), returning ConsumptionResolutionError(MALFORMED_MANIFEST) for
inputs missing the required top-level/nested keys, and only then delegates
to the existing from_dict() for the actual reconstruction.
"""

from __future__ import annotations

from typing import Any, Dict, Union

from ggm.consumption.types import ResolvedConsumptionManifest
from ggm.consumption.errors import ConsumptionResolutionError, ConsumptionResolutionErrorType

__all__ = ["serialize_manifest", "deserialize_manifest"]

_REQUIRED_TOP_LEVEL = [
    "manifest_version", "manifest_id", "governance", "capability",
    "deployment", "mandatory_kernel", "contract_version", "resolver_version",
    "resolution_trace",
]
_REQUIRED_GOVERNANCE = ["selection_id", "selection_version", "profiles_resolved"]
_REQUIRED_CAPABILITY = ["capability_profile_id", "capability_profile_version", "operations_enabled"]
_REQUIRED_DEPLOYMENT = ["deployment_profile_id", "deployment_profile_version", "deployment_mode"]
_REQUIRED_MANDATORY_KERNEL = ["kernel_version", "mandatory_invariants"]


def serialize_manifest(manifest: ResolvedConsumptionManifest) -> Dict[str, Any]:
    return manifest.to_dict()


def deserialize_manifest(d: Any) -> Union[ResolvedConsumptionManifest, ConsumptionResolutionError]:
    if not isinstance(d, dict):
        return ConsumptionResolutionError(
            error_type=ConsumptionResolutionErrorType.MALFORMED_MANIFEST,
            details="serialized manifest must be a dict",
        )

    missing = [k for k in _REQUIRED_TOP_LEVEL if k not in d]
    if missing:
        return ConsumptionResolutionError(
            error_type=ConsumptionResolutionErrorType.MALFORMED_MANIFEST,
            details=f"missing required top-level keys: {missing}",
        )

    for section_name, required_keys in (
        ("governance", _REQUIRED_GOVERNANCE),
        ("capability", _REQUIRED_CAPABILITY),
        ("deployment", _REQUIRED_DEPLOYMENT),
        ("mandatory_kernel", _REQUIRED_MANDATORY_KERNEL),
    ):
        section = d.get(section_name)
        if not isinstance(section, dict):
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.MALFORMED_MANIFEST,
                details=f"'{section_name}' section must be a dict",
            )
        missing_nested = [k for k in required_keys if k not in section]
        if missing_nested:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.MALFORMED_MANIFEST,
                details=f"'{section_name}' missing required keys: {missing_nested}",
            )

    try:
        return ResolvedConsumptionManifest.from_dict(d)
    except (KeyError, TypeError, ValueError) as e:
        return ConsumptionResolutionError(
            error_type=ConsumptionResolutionErrorType.MALFORMED_MANIFEST,
            details=f"malformed manifest: {e}",
        )
