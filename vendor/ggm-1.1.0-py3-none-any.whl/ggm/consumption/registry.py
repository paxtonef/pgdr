"""
ggm.consumption.registry — canonical-state access for Consumption Resolution
(GGM P1.3 §7, §10).

This module does not create a second governance-profile registry or a second
invariant registry. It wraps the existing canonical sources:

  * governance profiles: ggm.profiles.build_default_profiles() — the same
    registry ProfileResolver itself is constructed with everywhere else in
    this codebase (see e.g. test_ggm_adversarial.py, ggm.contract.interface).
  * mandatory kernel version: ggm.contract.types.RUNTIME_VERSION — the same
    runtime-identity constant already established at P1.2, reused rather than
    re-invented.
  * mandatory invariant IDs: ggm.invariants.MANDATORY_INVARIANT_IDS — read
    directly from the invariant layer itself (see below), not transcribed.

MANDATORY_INVARIANT_IDS — D1 closure correction
-------------------------------------------------
At initial P1.3 delivery this module maintained its own local transcription
of the invariant IDs (GGM-I01/I03/I08/I10), reconstructed from comments
scattered across ggm/invariants/__init__.py. P1.3 closure review (D1)
correctly identified this as a single-source-of-truth violation: the
identity of the mandatory invariant set should be owned by the invariant
layer itself, not duplicated in a consuming module.

Corrected: ggm.invariants now exposes MANDATORY_INVARIANT_IDS as its own
canonical, machine-readable constant (added there for exactly this purpose,
introducing no new invariant, no behavior change, no enforcement change, no
ID change — see ggm/invariants/__init__.py's own comment for provenance).
This module now only re-exports that same list object — it does not
redefine or re-derive it.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from ggm.model import DecisionType  # noqa: F401  (re-export convenience only)
from ggm.profiles import GovernanceProfile, build_default_profiles
from ggm.contract.types import RUNTIME_VERSION as _CANONICAL_KERNEL_VERSION
from ggm.invariants import MANDATORY_INVARIANT_IDS

__all__ = [
    "MANDATORY_INVARIANT_IDS",
    "CANONICAL_KERNEL_VERSION",
    "canonical_profile_registry",
    "lookup_profile",
]

# The mandatory kernel version consumers resolve against. Reuses the exact
# constant ggm.contract established at P1.2 rather than introducing a second
# versioning scheme.
CANONICAL_KERNEL_VERSION: str = _CANONICAL_KERNEL_VERSION


def canonical_profile_registry() -> Dict[str, GovernanceProfile]:
    """The canonical GGM governance-profile registry — the same
    build_default_profiles() result used to construct ProfileResolver
    everywhere else in this codebase. A fresh dict per call (no shared
    mutable global state)."""
    return build_default_profiles()


def lookup_profile(
    profile_id: str,
    profile_version: str,
    registry: Optional[Dict[str, GovernanceProfile]] = None,
) -> Optional[GovernanceProfile]:
    """Resolve a single canonical profile reference. Returns None if the
    profile_id is unknown or the declared version does not match the
    canonical profile's version — no fallback to a similarly named profile
    (per §3.1 "No fallback to a similarly named profile")."""
    reg = registry if registry is not None else canonical_profile_registry()
    profile = reg.get(profile_id)
    if profile is None:
        return None
    if profile.version != profile_version:
        return None
    return profile
