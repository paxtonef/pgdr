"""
ggm.consumption.errors — P1.3 Consumption Resolution error channel (§12).

ConsumptionResolutionError is a configuration/resolution failure — it is
neither a GovernanceResult (§9: resolution failures are never expressed as
GovernanceResult(BLOCK)) nor forced into P1.2's ConsumptionError (§12:
"They also need not be forced into P1.2 ConsumptionError if doing so would
conflate runtime delivery failure with pre-runtime resolution failure").
This is a deliberately separate, third type.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional

from ggm.consumption.types import RESOLVER_VERSION

__all__ = ["ConsumptionResolutionErrorType", "ConsumptionResolutionError"]


class ConsumptionResolutionErrorType(str, Enum):
    """Exhaustive per §12."""
    UNKNOWN_OPERATION = "UNKNOWN_OPERATION"
    UNKNOWN_GOVERNANCE_PROFILE = "UNKNOWN_GOVERNANCE_PROFILE"
    INVALID_GOVERNANCE_SELECTION = "INVALID_GOVERNANCE_SELECTION"
    INVALID_CAPABILITY_PROFILE = "INVALID_CAPABILITY_PROFILE"
    INVALID_DEPLOYMENT_PROFILE = "INVALID_DEPLOYMENT_PROFILE"
    INCOMPATIBLE_DECLARATIONS = "INCOMPATIBLE_DECLARATIONS"
    MANDATORY_KERNEL_MISMATCH = "MANDATORY_KERNEL_MISMATCH"
    MANDATORY_INVARIANT_VIOLATION = "MANDATORY_INVARIANT_VIOLATION"
    CONTRACT_VERSION_MISMATCH = "CONTRACT_VERSION_MISMATCH"
    MALFORMED_MANIFEST = "MALFORMED_MANIFEST"


@dataclass
class ConsumptionResolutionError:
    """§12 envelope: error_type, details, resolver_version, input_reference."""
    error_type: ConsumptionResolutionErrorType = ConsumptionResolutionErrorType.MALFORMED_MANIFEST
    details: str = ""
    resolver_version: str = RESOLVER_VERSION
    input_reference: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_type": self.error_type.value,
            "details": self.details,
            "resolver_version": self.resolver_version,
            "input_reference": self.input_reference,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConsumptionResolutionError":
        return cls(
            error_type=ConsumptionResolutionErrorType(d.get("error_type", "MALFORMED_MANIFEST")),
            details=d.get("details", ""),
            resolver_version=d.get("resolver_version", RESOLVER_VERSION),
            input_reference=d.get("input_reference"),
        )
