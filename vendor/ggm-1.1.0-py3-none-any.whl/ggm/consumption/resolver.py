"""
ggm.consumption.resolver — the single canonical Consumption Resolver (§5-§7).

There is exactly one resolution path (§5: "There MUST be one canonical
resolution path. No duplicated resolution logic in future adapters or
consumers."). Executes R1-R8 in order (§6).

resolve() takes three separate typed arguments, never a merged dict (§4):

    resolve(governance_selection, capability_profile, deployment_profile)
        -> ResolvedConsumptionManifest | ConsumptionResolutionError

Decision record — consumer_id (§8 vs §5):
§8's ResolvedConsumptionManifest schema requires a consumer_id field, but
§3's three-axis input model and §5's "required conceptual shape" both frame
the resolver as taking exactly the three orthogonal axis arguments — no
axis carries a consumer identity, and adding a fourth *axis* would
contradict "Three Orthogonal Inputs" as the input model. consumer_id is not
a governance/capability/deployment concern, so it is accepted as an
optional keyword-only argument, separate from and in addition to the three
required positional axis arguments, rather than folded into any axis or
promoted to a fourth axis. This is a documented decision (see
docs/P1.3_Consumption_Resolution_Result.md), not a silent schema
extension.

No governance evaluation occurs anywhere in this module (§6 R6) — it never
imports or calls InvariantEngine.check_transition,
TransitionEngine.evaluate, EscalationDetector.detect, or
GovernanceDecisionEngine.decide. It only checks profile *existence* via the
canonical registry (ggm.consumption.registry), never merges or evaluates
profile rules (§7).
"""

from __future__ import annotations

import uuid
from typing import List, Optional, Union

from ggm.contract.types import CONTRACT_VERSION, Operation

from ggm.consumption.types import (
    RESOLVER_VERSION,
    GovernanceProfileSelection,
    GGMCapabilityProfile,
    DeploymentProfile,
    ResolvedProfileRef,
    MandatoryKernel,
    ResolutionTrace,
    ResolvedConsumptionManifest,
)
from ggm.consumption.errors import ConsumptionResolutionError, ConsumptionResolutionErrorType
from ggm.consumption.registry import (
    MANDATORY_INVARIANT_IDS,
    CANONICAL_KERNEL_VERSION,
    canonical_profile_registry,
    lookup_profile,
)

__all__ = ["ConsumptionResolver"]

# Deterministic manifest_id namespace (§13: identical inputs must resolve to
# semantically identical manifests; manifest_id is derived via uuid5, not
# uuid4, so it is stable across executions given identical inputs — unlike
# resolution_id, which §13 explicitly allows to vary).
_MANIFEST_ID_NAMESPACE = uuid.UUID("6f1d1f2e-9c1a-4b7a-9e3a-6b8e6f0a9c1d")


class ConsumptionResolver:
    """The one canonical resolver (§5). Constructed with an optional profile
    registry (defaults to the canonical ggm.profiles.build_default_profiles()
    result, matching the pattern already used by DefaultGGMConsumer)."""

    def __init__(self, profile_registry: Optional[dict] = None):
        self._profile_registry = (
            profile_registry if profile_registry is not None else canonical_profile_registry()
        )

    def resolve(
        self,
        governance_selection: GovernanceProfileSelection,
        capability_profile: GGMCapabilityProfile,
        deployment_profile: DeploymentProfile,
        consumer_id: Optional[str] = None,
    ) -> Union[ResolvedConsumptionManifest, ConsumptionResolutionError]:
        validations_applied: List[str] = []

        # ------------------------------------------------------------
        # R1 — validate individual axes independently
        # ------------------------------------------------------------
        validations_applied.append("R1_validate_axes")

        gov_problems = governance_selection.validate()
        if gov_problems:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.INVALID_GOVERNANCE_SELECTION,
                details="; ".join(gov_problems),
                input_reference=governance_selection.selection_id or None,
            )

        cap_problems = capability_profile.validate()
        if cap_problems:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.INVALID_CAPABILITY_PROFILE,
                details="; ".join(cap_problems),
                input_reference=capability_profile.capability_profile_id or None,
            )

        dep_problems = deployment_profile.validate()
        if dep_problems:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.INVALID_DEPLOYMENT_PROFILE,
                details="; ".join(dep_problems),
                input_reference=deployment_profile.deployment_profile_id or None,
            )

        # ------------------------------------------------------------
        # R2 — resolve governance-profile references against the canonical
        # registry. No fallback to a similarly named profile (§3.1).
        # ------------------------------------------------------------
        validations_applied.append("R2_resolve_governance_profile_refs")

        resolved_profiles: List[ResolvedProfileRef] = []
        for ref in governance_selection.profile_refs:
            profile = lookup_profile(ref.profile_id, ref.profile_version, self._profile_registry)
            if profile is None:
                return ConsumptionResolutionError(
                    error_type=ConsumptionResolutionErrorType.UNKNOWN_GOVERNANCE_PROFILE,
                    details=f"unknown governance profile: {ref.profile_id}@{ref.profile_version}",
                    input_reference=f"{ref.profile_id}@{ref.profile_version}",
                )
            resolved_profiles.append(ResolvedProfileRef(profile_id=profile.profile_id, profile_version=profile.version))

        # ------------------------------------------------------------
        # R3 — validate requested operations against the frozen P1.2
        # operation vocabulary.
        # ------------------------------------------------------------
        validations_applied.append("R3_validate_operations")

        for op_str in capability_profile.operations_required:
            try:
                Operation(op_str)
            except ValueError:
                return ConsumptionResolutionError(
                    error_type=ConsumptionResolutionErrorType.UNKNOWN_OPERATION,
                    details=f"unknown operation: {op_str!r}",
                    input_reference=capability_profile.capability_profile_id or None,
                )

        # ------------------------------------------------------------
        # R4 — establish the mandatory governance floor. Injected from
        # canonical GGM state, never from consumer input (§10). The
        # consumer's declared mandatory_kernel_version is checked against
        # the canonical kernel version; any mismatch is rejected outright —
        # there is no negotiation/downgrade path, since that would let a
        # consumer request a weaker floor (§3.2: "mandatory kernel
        # declaration cannot disable or reduce the mandatory floor").
        # ------------------------------------------------------------
        validations_applied.append("R4_establish_mandatory_floor")

        if capability_profile.mandatory_kernel_version != CANONICAL_KERNEL_VERSION:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.MANDATORY_KERNEL_MISMATCH,
                details=(
                    f"requested kernel version {capability_profile.mandatory_kernel_version!r} "
                    f"does not match canonical kernel version {CANONICAL_KERNEL_VERSION!r}"
                ),
                input_reference=capability_profile.capability_profile_id or None,
            )

        mandatory_kernel = MandatoryKernel(
            kernel_version=CANONICAL_KERNEL_VERSION,
            mandatory_invariants=list(MANDATORY_INVARIANT_IDS),
        )

        # ------------------------------------------------------------
        # R5 — cross-axis compatibility checks only. No mutation of one
        # axis based on another (§6 R5).
        #
        # Only the logically self-evident deployment-declaration
        # contradictions named in the field semantics themselves are
        # checked here — P1.3 does not invent a broader compatibility
        # matrix beyond what the field names make unambiguous.
        # ------------------------------------------------------------
        validations_applied.append("R5_cross_axis_compatibility")

        if deployment_profile.standalone_required and deployment_profile.shared_service_allowed:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.INCOMPATIBLE_DECLARATIONS,
                details="standalone_required and shared_service_allowed cannot both be true",
                input_reference=deployment_profile.deployment_profile_id or None,
            )

        if deployment_profile.offline_required and deployment_profile.shared_service_allowed:
            return ConsumptionResolutionError(
                error_type=ConsumptionResolutionErrorType.INCOMPATIBLE_DECLARATIONS,
                details="offline_required and shared_service_allowed cannot both be true",
                input_reference=deployment_profile.deployment_profile_id or None,
            )

        # CONTRACT_VERSION_MISMATCH: §12 requires this error type to exist,
        # but no axis in the frozen §3 input model carries a
        # consumer-requested contract_version to compare against
        # ggm.contract.types.CONTRACT_VERSION — so this resolver has no
        # input to check it against and never raises it. Recorded as an
        # impossibility in the Result artifact rather than inventing a new
        # field on GGMCapabilityProfile to manufacture a check.

        # ------------------------------------------------------------
        # R6 — produce the canonical effective declaration. Pure pass-
        # through of validated/resolved inputs; no governance evaluation.
        # ------------------------------------------------------------
        validations_applied.append("R6_produce_effective_declaration")

        manifest_id = str(uuid.uuid5(
            _MANIFEST_ID_NAMESPACE,
            "|".join([
                consumer_id or "",
                governance_selection.selection_id, governance_selection.selection_version,
                capability_profile.capability_profile_id, capability_profile.capability_profile_version,
                deployment_profile.deployment_profile_id, deployment_profile.deployment_profile_version,
                RESOLVER_VERSION,
            ]),
        ))

        # ------------------------------------------------------------
        # R7 — produce trace
        # ------------------------------------------------------------
        validations_applied.append("R7_produce_trace")

        trace = ResolutionTrace(
            input_versions={
                "governance_selection": governance_selection.selection_version,
                "capability_profile": capability_profile.capability_profile_version,
                "deployment_profile": deployment_profile.deployment_profile_version,
            },
            profiles_resolved=[f"{p.profile_id}@{p.profile_version}" for p in resolved_profiles],
            validations_applied=validations_applied,
            # non-semantic per §13
            resolution_id=str(uuid.uuid4()),
        )

        # ------------------------------------------------------------
        # R8 — serialize canonical manifest (to_dict/from_dict provided by
        # ResolvedConsumptionManifest itself; construction here just
        # populates it).
        # ------------------------------------------------------------
        return ResolvedConsumptionManifest(
            manifest_id=manifest_id,
            consumer_id=consumer_id,
            governance_selection_id=governance_selection.selection_id,
            governance_selection_version=governance_selection.selection_version,
            profiles_resolved=resolved_profiles,
            capability_profile_id=capability_profile.capability_profile_id,
            capability_profile_version=capability_profile.capability_profile_version,
            operations_enabled=list(capability_profile.operations_required),
            persistence_required=capability_profile.persistence_required,
            audit_requirements=list(capability_profile.audit_requirements),
            deployment_profile_id=deployment_profile.deployment_profile_id,
            deployment_profile_version=deployment_profile.deployment_profile_version,
            deployment_mode=deployment_profile.deployment_mode,
            offline_required=deployment_profile.offline_required,
            standalone_required=deployment_profile.standalone_required,
            version_pinning_required=deployment_profile.version_pinning_required,
            shared_service_allowed=deployment_profile.shared_service_allowed,
            mandatory_kernel=mandatory_kernel,
            contract_version=CONTRACT_VERSION,
            resolver_version=RESOLVER_VERSION,
            resolution_trace=trace,
        )
