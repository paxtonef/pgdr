"""
ggm.consumption — GGM P1.3 Consumption Resolution.

Transforms a consumer's declared GGM consumption requirements (three
orthogonal axes: GovernanceProfileSelection, GGMCapabilityProfile,
DeploymentProfile) into a canonical, validated, auditable
ResolvedConsumptionManifest — or a ConsumptionResolutionError if the
declaration cannot be resolved.

This package does not build a bounded runtime, adapter, or service. It
answers "what has been resolved for this consumer", not "how is it run".
"""

from ggm.consumption.types import (
    RESOLVER_VERSION,
    CanonicalProfileRef,
    GovernanceProfileSelection,
    GGMCapabilityProfile,
    DeploymentProfile,
    ResolvedProfileRef,
    MandatoryKernel,
    ResolutionTrace,
    ResolvedConsumptionManifest,
)
from ggm.consumption.errors import ConsumptionResolutionErrorType, ConsumptionResolutionError
from ggm.consumption.resolver import ConsumptionResolver
from ggm.consumption.registry import MANDATORY_INVARIANT_IDS, CANONICAL_KERNEL_VERSION
from ggm.consumption.serialization import serialize_manifest, deserialize_manifest

__all__ = [
    "RESOLVER_VERSION",
    "CanonicalProfileRef",
    "GovernanceProfileSelection",
    "GGMCapabilityProfile",
    "DeploymentProfile",
    "ResolvedProfileRef",
    "MandatoryKernel",
    "ResolutionTrace",
    "ResolvedConsumptionManifest",
    "ConsumptionResolutionErrorType",
    "ConsumptionResolutionError",
    "ConsumptionResolver",
    "MANDATORY_INVARIANT_IDS",
    "CANONICAL_KERNEL_VERSION",
    "serialize_manifest",
    "deserialize_manifest",
]
