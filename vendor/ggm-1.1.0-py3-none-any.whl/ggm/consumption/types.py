"""
ggm.consumption.types — GGM P1.3 Consumption Resolution types (§3, §8).

Three orthogonal axis inputs (GovernanceProfileSelection, GGMCapabilityProfile,
DeploymentProfile) and the ResolvedConsumptionManifest they resolve into.

Mechanical orthogonality (§4): each axis dataclass below defines only the
fields belonging to its own axis. GovernanceProfileSelection has no
operations/deployment fields; GGMCapabilityProfile has no profile_refs/
deployment fields; DeploymentProfile has no profile_refs/operations fields.
This is enforced by the type model itself — there is no shared/generic
config object, and the resolver's signature (see ggm.consumption.resolver)
takes three separate typed arguments, never a merged dict.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

__all__ = [
    "RESOLVER_VERSION",
    "CanonicalProfileRef",
    "GovernanceProfileSelection",
    "GGMCapabilityProfile",
    "DeploymentProfile",
    "ResolvedProfileRef",
    "MandatoryKernel",
    "ResolutionTrace",
    "ResolvedConsumptionManifest",
]

# P1.3 resolver's own version. Distinct from ggm.contract.types.CONTRACT_VERSION
# (the P1.2 consumer-contract version) and from
# ggm.consumption.registry.CANONICAL_KERNEL_VERSION (the GGM runtime/kernel
# version) — three separate, deliberately non-conflated version identities.
RESOLVER_VERSION = "1.3"


# =============================================================================
# AXIS 1 — GovernanceProfileSelection (§3.1): "what governance rules apply?"
# =============================================================================

@dataclass
class CanonicalProfileRef:
    profile_id: str = ""
    profile_version: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"profile_id": self.profile_id, "profile_version": self.profile_version}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "CanonicalProfileRef":
        return cls(profile_id=d.get("profile_id", ""), profile_version=d.get("profile_version", ""))


@dataclass
class GovernanceProfileSelection:
    """Axis 1. May reference only canonical GGM-owned governance profiles;
    carries no governance rules, capability declarations, or deployment
    constraints of its own (§4 — enforced by the absence of those fields
    here, not by a runtime check)."""
    selection_id: str = ""
    selection_version: str = ""
    profile_refs: List[CanonicalProfileRef] = field(default_factory=list)

    def validate(self) -> List[str]:
        """Structural validation only (§6 R1) — does not check whether
        referenced profiles actually exist; that is R2's job."""
        problems: List[str] = []
        if not self.selection_id:
            problems.append("selection_id is required")
        if not self.selection_version:
            problems.append("selection_version is required")

        seen_ids = set()
        for i, ref in enumerate(self.profile_refs):
            if not ref.profile_id:
                problems.append(f"profile_refs[{i}].profile_id is required")
            if not ref.profile_version:
                problems.append(f"profile_refs[{i}].profile_version is required")
            # §3.1: "duplicate profile references are invalid" — a second
            # reference to the same profile_id (regardless of version) is a
            # duplicate; requesting the same governance profile twice (even
            # at two different versions) is not a meaningful selection.
            if ref.profile_id and ref.profile_id in seen_ids:
                problems.append(f"duplicate profile reference: {ref.profile_id}")
            seen_ids.add(ref.profile_id)

        return problems

    def to_dict(self) -> Dict[str, Any]:
        return {
            "selection_id": self.selection_id,
            "selection_version": self.selection_version,
            "profile_refs": [r.to_dict() for r in self.profile_refs],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernanceProfileSelection":
        return cls(
            selection_id=d.get("selection_id", ""),
            selection_version=d.get("selection_version", ""),
            profile_refs=[CanonicalProfileRef.from_dict(r) for r in d.get("profile_refs", [])],
        )


# =============================================================================
# AXIS 2 — GGMCapabilityProfile (§3.2): "what GGM machinery does this
# consumer require?"
# =============================================================================

@dataclass
class GGMCapabilityProfile:
    """Axis 2. operations_required uses only the frozen P1.2 operation
    vocabulary (ggm.contract.types.Operation values, as strings — kept as
    raw strings here rather than the Operation enum itself so that an
    unrecognized value is a distinct, reportable UNKNOWN_OPERATION resolution
    error (§6 R3) rather than a structural/type failure at construction
    time). Carries no governance profile references or deployment
    constraints of its own (§4)."""
    capability_profile_id: str = ""
    capability_profile_version: str = ""
    operations_required: List[str] = field(default_factory=list)
    mandatory_kernel_version: str = ""
    persistence_required: bool = False
    audit_requirements: List[str] = field(default_factory=list)

    def validate(self) -> List[str]:
        """Structural validation only (§6 R1) — does not check whether each
        requested operation is actually in the frozen vocabulary; that is
        R3's job (kept separate per §6's distinct steps and §12's distinct
        UNKNOWN_OPERATION error type)."""
        problems: List[str] = []
        if not self.capability_profile_id:
            problems.append("capability_profile_id is required")
        if not self.capability_profile_version:
            problems.append("capability_profile_version is required")
        if not self.mandatory_kernel_version:
            problems.append("mandatory_kernel_version is required")
        if not isinstance(self.operations_required, list):
            problems.append("operations_required must be a list")
        if not isinstance(self.persistence_required, bool):
            problems.append("persistence_required must be a boolean")
        if not isinstance(self.audit_requirements, list):
            problems.append("audit_requirements must be a list")
        return problems

    def to_dict(self) -> Dict[str, Any]:
        return {
            "capability_profile_id": self.capability_profile_id,
            "capability_profile_version": self.capability_profile_version,
            "operations_required": list(self.operations_required),
            "mandatory_kernel_version": self.mandatory_kernel_version,
            "persistence_required": self.persistence_required,
            "audit_requirements": list(self.audit_requirements),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GGMCapabilityProfile":
        return cls(
            capability_profile_id=d.get("capability_profile_id", ""),
            capability_profile_version=d.get("capability_profile_version", ""),
            operations_required=list(d.get("operations_required", [])),
            mandatory_kernel_version=d.get("mandatory_kernel_version", ""),
            persistence_required=d.get("persistence_required", False),
            audit_requirements=list(d.get("audit_requirements", [])),
        )


# =============================================================================
# AXIS 3 — DeploymentProfile (§3.3): "how / where must governance be
# consumable?"
# =============================================================================

@dataclass
class DeploymentProfile:
    """Axis 3. Declarative only (§3.3) — P1.3 builds no adapter and reads
    no field here when constructing the governance or capability sections
    of the manifest. Carries no governance profile references or operation
    requirements of its own (§4)."""
    deployment_profile_id: str = ""
    deployment_profile_version: str = ""
    deployment_mode: str = ""
    offline_required: bool = False
    standalone_required: bool = False
    version_pinning_required: bool = False
    shared_service_allowed: bool = False

    def validate(self) -> List[str]:
        problems: List[str] = []
        if not self.deployment_profile_id:
            problems.append("deployment_profile_id is required")
        if not self.deployment_profile_version:
            problems.append("deployment_profile_version is required")
        if not self.deployment_mode:
            problems.append("deployment_mode is required")
        for name in ("offline_required", "standalone_required", "version_pinning_required", "shared_service_allowed"):
            if not isinstance(getattr(self, name), bool):
                problems.append(f"{name} must be a boolean")
        return problems

    def to_dict(self) -> Dict[str, Any]:
        return {
            "deployment_profile_id": self.deployment_profile_id,
            "deployment_profile_version": self.deployment_profile_version,
            "deployment_mode": self.deployment_mode,
            "offline_required": self.offline_required,
            "standalone_required": self.standalone_required,
            "version_pinning_required": self.version_pinning_required,
            "shared_service_allowed": self.shared_service_allowed,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DeploymentProfile":
        return cls(
            deployment_profile_id=d.get("deployment_profile_id", ""),
            deployment_profile_version=d.get("deployment_profile_version", ""),
            deployment_mode=d.get("deployment_mode", ""),
            offline_required=d.get("offline_required", False),
            standalone_required=d.get("standalone_required", False),
            version_pinning_required=d.get("version_pinning_required", False),
            shared_service_allowed=d.get("shared_service_allowed", False),
        )


# =============================================================================
# ResolvedConsumptionManifest (§8)
# =============================================================================

@dataclass
class ResolvedProfileRef:
    """A governance-profile reference confirmed to exist in the canonical
    registry at the stated version — not a merged/effective rule set (§7:
    P1.3 does not duplicate ProfileResolver's merging semantics)."""
    profile_id: str = ""
    profile_version: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"profile_id": self.profile_id, "profile_version": self.profile_version}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ResolvedProfileRef":
        return cls(profile_id=d.get("profile_id", ""), profile_version=d.get("profile_version", ""))


@dataclass
class MandatoryKernel:
    kernel_version: str = ""
    mandatory_invariants: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {"kernel_version": self.kernel_version, "mandatory_invariants": list(self.mandatory_invariants)}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MandatoryKernel":
        return cls(
            kernel_version=d.get("kernel_version", ""),
            mandatory_invariants=list(d.get("mandatory_invariants", [])),
        )


@dataclass
class ResolutionTrace:
    input_versions: Dict[str, str] = field(default_factory=dict)
    profiles_resolved: List[str] = field(default_factory=list)
    validations_applied: List[str] = field(default_factory=list)
    # Non-semantic per §13 — may vary between executions on identical input.
    resolution_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "input_versions": dict(self.input_versions),
            "profiles_resolved": list(self.profiles_resolved),
            "validations_applied": list(self.validations_applied),
            "resolution_id": self.resolution_id,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ResolutionTrace":
        return cls(
            input_versions=dict(d.get("input_versions", {})),
            profiles_resolved=list(d.get("profiles_resolved", [])),
            validations_applied=list(d.get("validations_applied", [])),
            resolution_id=d.get("resolution_id", str(uuid.uuid4())),
        )


@dataclass
class ResolvedConsumptionManifest:
    """§8. Declarative — describes the governance-consumption surface
    available to a consumer. Not a GovernanceResult, GovernanceProfile,
    runtime executable, or deployment package (§9)."""
    manifest_version: str = "1.0"
    # Deterministic per §13 (identical inputs -> semantically identical
    # manifest): derived (uuid5, not uuid4) from the resolved axis
    # identities rather than randomly generated. See
    # ggm.consumption.resolver for the derivation. consumer_id is not part
    # of the three-axis input model (§3) but is required by this schema;
    # ggm.consumption.resolver.ConsumptionResolver.resolve() accepts it as
    # an optional 4th keyword argument, separate from the three required
    # positional axis arguments — see resolver module docstring for the
    # rationale, recorded as a decision in the Result artifact.
    manifest_id: str = ""
    consumer_id: Optional[str] = None

    # governance
    governance_selection_id: str = ""
    governance_selection_version: str = ""
    profiles_resolved: List[ResolvedProfileRef] = field(default_factory=list)

    # capability
    capability_profile_id: str = ""
    capability_profile_version: str = ""
    operations_enabled: List[str] = field(default_factory=list)
    persistence_required: bool = False
    audit_requirements: List[str] = field(default_factory=list)

    # deployment
    deployment_profile_id: str = ""
    deployment_profile_version: str = ""
    deployment_mode: str = ""
    offline_required: bool = False
    standalone_required: bool = False
    version_pinning_required: bool = False
    shared_service_allowed: bool = False

    # mandatory floor
    mandatory_kernel: MandatoryKernel = field(default_factory=MandatoryKernel)

    contract_version: str = ""
    resolver_version: str = RESOLVER_VERSION

    resolution_trace: ResolutionTrace = field(default_factory=ResolutionTrace)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "manifest_version": self.manifest_version,
            "manifest_id": self.manifest_id,
            "consumer_id": self.consumer_id,
            "governance": {
                "selection_id": self.governance_selection_id,
                "selection_version": self.governance_selection_version,
                "profiles_resolved": [p.to_dict() for p in self.profiles_resolved],
            },
            "capability": {
                "capability_profile_id": self.capability_profile_id,
                "capability_profile_version": self.capability_profile_version,
                "operations_enabled": list(self.operations_enabled),
                "persistence_required": self.persistence_required,
                "audit_requirements": list(self.audit_requirements),
            },
            "deployment": {
                "deployment_profile_id": self.deployment_profile_id,
                "deployment_profile_version": self.deployment_profile_version,
                "deployment_mode": self.deployment_mode,
                "offline_required": self.offline_required,
                "standalone_required": self.standalone_required,
                "version_pinning_required": self.version_pinning_required,
                "shared_service_allowed": self.shared_service_allowed,
            },
            "mandatory_kernel": self.mandatory_kernel.to_dict(),
            "contract_version": self.contract_version,
            "resolver_version": self.resolver_version,
            "resolution_trace": self.resolution_trace.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ResolvedConsumptionManifest":
        gov = d.get("governance", {})
        cap = d.get("capability", {})
        dep = d.get("deployment", {})
        return cls(
            manifest_version=d.get("manifest_version", "1.0"),
            manifest_id=d.get("manifest_id", ""),
            consumer_id=d.get("consumer_id"),
            governance_selection_id=gov.get("selection_id", ""),
            governance_selection_version=gov.get("selection_version", ""),
            profiles_resolved=[ResolvedProfileRef.from_dict(p) for p in gov.get("profiles_resolved", [])],
            capability_profile_id=cap.get("capability_profile_id", ""),
            capability_profile_version=cap.get("capability_profile_version", ""),
            operations_enabled=list(cap.get("operations_enabled", [])),
            persistence_required=cap.get("persistence_required", False),
            audit_requirements=list(cap.get("audit_requirements", [])),
            deployment_profile_id=dep.get("deployment_profile_id", ""),
            deployment_profile_version=dep.get("deployment_profile_version", ""),
            deployment_mode=dep.get("deployment_mode", ""),
            offline_required=dep.get("offline_required", False),
            standalone_required=dep.get("standalone_required", False),
            version_pinning_required=dep.get("version_pinning_required", False),
            shared_service_allowed=dep.get("shared_service_allowed", False),
            mandatory_kernel=MandatoryKernel.from_dict(d.get("mandatory_kernel", {})),
            contract_version=d.get("contract_version", ""),
            resolver_version=d.get("resolver_version", RESOLVER_VERSION),
            resolution_trace=ResolutionTrace.from_dict(d.get("resolution_trace", {})),
        )
