"""ggm.persistence — ClaimStore, minimal full round-trip storage (mechanical extraction from ggm_core.py)."""

from __future__ import annotations

import uuid
import json
import copy
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, List, Dict, Tuple, Set
from pathlib import Path


from ggm.model import (
    GovernedClaim, GovernedRelation, TransitionEvent, GovernanceDecision,
)

# =============================================================================
# MINIMAL STORAGE — Full round-trip
# =============================================================================

class ClaimStore:
    def __init__(self, path: Optional[Path] = None):
        self.claims: Dict[str, GovernedClaim] = {}
        self.relations: Dict[str, GovernedRelation] = {}
        self.events: List[TransitionEvent] = []
        self.decisions: List[GovernanceDecision] = []
        self.path = path

    def save_claim(self, claim: GovernedClaim) -> None:
        self.claims[claim.id] = claim
        self._persist()

    def save_relation(self, relation: GovernedRelation) -> None:
        self.relations[relation.id] = relation
        self._persist()

    def save_event(self, event: TransitionEvent) -> None:
        self.events.append(event)
        self._persist()

    def save_decision(self, decision: GovernanceDecision) -> None:
        self.decisions.append(decision)
        self._persist()

    def get_claim(self, claim_id: str) -> Optional[GovernedClaim]:
        return self.claims.get(claim_id)

    def _persist(self) -> None:
        if self.path is None:
            return
        data = {
            "claims": {k: v.to_dict() for k, v in self.claims.items()},
            "relations": {k: v.to_dict() for k, v in self.relations.items()},
            "events": [e.to_dict() for e in self.events],
            "decisions": [d.to_dict() for d in self.decisions],
        }
        self.path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")

    def load(self) -> None:
        if self.path is None or not self.path.exists():
            return
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        self.claims = {k: GovernedClaim.from_dict(v) for k, v in raw.get("claims", {}).items()}
        self.relations = {k: GovernedRelation.from_dict(v) for k, v in raw.get("relations", {}).items()}
        self.events = [TransitionEvent.from_dict(e) for e in raw.get("events", [])]
        self.decisions = [GovernanceDecision.from_dict(d) for d in raw.get("decisions", [])]

