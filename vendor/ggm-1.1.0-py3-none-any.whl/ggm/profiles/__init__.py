"""ggm.profiles — GovernanceProfile, EffectiveProfile, ProfileResolver, and default profile factory (mechanical extraction from ggm_core.py)."""

from __future__ import annotations

import uuid
import json
import copy
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, List, Dict, Tuple, Set
from pathlib import Path


from ggm.model import (
    EpistemicStatus, AuthorityLevel, RiskLevel, LifecycleStatus,
    ClaimFamily, RelationType, TransitionMode, DecisionType,
    UncertaintyLevel, OriginType,
    GovernedClaim, GovernedRelation,
)

# =============================================================================
# GOVERNANCE PROFILE / EFFECTIVE PROFILE
# =============================================================================

@dataclass
class GovernanceProfile:
    profile_id: str = ""
    version: str = "1.0"
    parent_profiles: List[str] = field(default_factory=list)
    applies_to: Dict[str, List[str]] = field(default_factory=dict)
    generation_policy: Dict[str, Any] = field(default_factory=dict)
    claim_policy: Dict[str, Any] = field(default_factory=dict)
    evidence_policy: Dict[str, Any] = field(default_factory=dict)
    transition_policy: Dict[str, Any] = field(default_factory=dict)
    authority_policy: Dict[str, Any] = field(default_factory=dict)
    operational_policy: Dict[str, Any] = field(default_factory=dict)
    verification_policy: Dict[str, Any] = field(default_factory=dict)
    fallback_policy: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernanceProfile":
        return cls(
            profile_id=d.get("profile_id", ""),
            version=d.get("version", "1.0"),
            parent_profiles=d.get("parent_profiles", []),
            applies_to=d.get("applies_to", {}),
            generation_policy=d.get("generation_policy", {}),
            claim_policy=d.get("claim_policy", {}),
            evidence_policy=d.get("evidence_policy", {}),
            transition_policy=d.get("transition_policy", {}),
            authority_policy=d.get("authority_policy", {}),
            operational_policy=d.get("operational_policy", {}),
            verification_policy=d.get("verification_policy", {}),
            fallback_policy=d.get("fallback_policy", {}),
        )


@dataclass
class EffectiveProfile:
    resolution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object_id: str = ""
    profiles_applied: List[str] = field(default_factory=list)
    effective_rules: Dict[str, Any] = field(default_factory=dict)
    conflicts: List[str] = field(default_factory=list)
    relaxations: List[str] = field(default_factory=list)
    resolution_timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "resolution_id": self.resolution_id,
            "object_id": self.object_id,
            "profiles_applied": self.profiles_applied,
            "effective_rules": self.effective_rules,
            "conflicts": self.conflicts,
            "relaxations": self.relaxations,
            "resolution_timestamp": self.resolution_timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EffectiveProfile":
        return cls(
            resolution_id=d.get("resolution_id", str(uuid.uuid4())),
            object_id=d.get("object_id", ""),
            profiles_applied=d.get("profiles_applied", []),
            effective_rules=d.get("effective_rules", {}),
            conflicts=d.get("conflicts", []),
            relaxations=d.get("relaxations", []),
            resolution_timestamp=datetime.fromisoformat(d["resolution_timestamp"]),
        )


# =============================================================================
# PROFILE RESOLVER
# =============================================================================

class ProfileResolver:
    """
    Resolves effective governance profile with inheritance, filtering, and
    restrictive precedence: FORBID > ESCALATE > GATED > ALLOW.
    """

    PRECEDENCE = {
        TransitionMode.FORBID: 4,
        TransitionMode.ESCALATE: 3,
        TransitionMode.GATED: 2,
        TransitionMode.ALLOW: 1,
    }

    def __init__(self, registry: Dict[str, GovernanceProfile]):
        self.registry = registry

    def resolve(self, obj: GovernedObject, context: Dict[str, str]) -> EffectiveProfile:
        # 1. Collect base profile
        base = self.registry.get("ggm.base")
        matched = [base] if base else []

        # 2. Resolve inheritance and filter by applies_to
        for pid, profile in self.registry.items():
            if pid == "ggm.base":
                continue
            # Resolve parents recursively
            resolved = self._resolve_profile(profile)
            # Check applies_to filters
            if self._profile_applies(resolved, obj, context):
                matched.append(resolved)

        # 3. Deduplicate by profile_id
        seen = set()
        unique = []
        for p in matched:
            if p.profile_id not in seen:
                seen.add(p.profile_id)
                unique.append(p)
        matched = unique

        # 4. Compose with restrictive precedence
        effective_rules: Dict[str, Any] = {"transitions": {}}
        conflicts: List[str] = []

        for profile in matched:
            if "transitions" in profile.transition_policy:
                for key, rule_def in profile.transition_policy["transitions"].items():
                    existing = effective_rules["transitions"].get(key)
                    new_mode = TransitionMode(rule_def.get("mode", "ALLOW"))
                    if existing:
                        existing_mode = TransitionMode(existing.get("mode", "ALLOW"))
                        if self.PRECEDENCE[new_mode] > self.PRECEDENCE[existing_mode]:
                            conflicts.append(
                                f"{profile.profile_id} strengthened {key}: {existing_mode.value} -> {new_mode.value}"
                            )
                            effective_rules["transitions"][key] = rule_def
                        elif self.PRECEDENCE[new_mode] < self.PRECEDENCE[existing_mode]:
                            conflicts.append(
                                f"{profile.profile_id} weakened {key} to {new_mode.value} — OVERRIDDEN by {existing_mode.value}"
                            )
                    else:
                        effective_rules["transitions"][key] = rule_def

            # Operational policy merge
            if "consequential_execution" in profile.operational_policy:
                current = effective_rules.get("consequential_execution", "ALLOW")
                new_val = profile.operational_policy["consequential_execution"]
                if self._mode_stronger(new_val, current):
                    effective_rules["consequential_execution"] = new_val

        return EffectiveProfile(
            object_id=obj.id,
            profiles_applied=[p.profile_id for p in matched],
            effective_rules=effective_rules,
            conflicts=conflicts,
        )

    def _resolve_profile(self, profile: GovernanceProfile, visited: Optional[Set[str]] = None) -> GovernanceProfile:
        """Recursively merge parent profiles into this profile."""
        if visited is None:
            visited = set()
        if profile.profile_id in visited:
            return profile
        visited.add(profile.profile_id)

        merged = copy.deepcopy(profile)
        for parent_id in profile.parent_profiles:
            parent = self.registry.get(parent_id)
            if not parent:
                continue
            resolved_parent = self._resolve_profile(parent, visited)
            # Parent transitions are inherited unless overridden
            if "transitions" in resolved_parent.transition_policy:
                parent_trans = resolved_parent.transition_policy["transitions"]
                child_trans = merged.transition_policy.setdefault("transitions", {})
                for key, rule_def in parent_trans.items():
                    if key not in child_trans:
                        child_trans[key] = rule_def
            # Inherit operational policy if child doesn't define
            if "consequential_execution" in resolved_parent.operational_policy:
                if "consequential_execution" not in merged.operational_policy:
                    merged.operational_policy["consequential_execution"] = resolved_parent.operational_policy["consequential_execution"]

        return merged

    @staticmethod
    def _profile_applies(profile: GovernanceProfile, obj: GovernedObject, context: Dict[str, str]) -> bool:
        """Check if profile's applies_to matches the object and context."""
        applies = profile.applies_to
        if not applies:
            return True

        # Domain match
        if "domains" in applies:
            if context.get("domain") not in applies["domains"]:
                return False

        # Capability match
        if "capabilities" in applies:
            if context.get("capability") not in applies["capabilities"]:
                return False

        # Claim family match
        if "claim_families" in applies:
            obj_families = {f.value for f in obj.classification.families}
            if not obj_families & set(applies["claim_families"]):
                return False

        # Risk level match
        if "risk_levels" in applies:
            if obj.risk.level.value not in applies["risk_levels"]:
                return False

        # Generative act match
        if "generative_acts" in applies:
            if context.get("generative_act") not in applies["generative_acts"]:
                return False

        return True

    @staticmethod
    def _mode_stronger(a: str, b: str) -> bool:
        order = {"FORBID": 4, "ESCALATE": 3, "GATED": 2, "ALLOW": 1}
        return order.get(a, 0) > order.get(b, 0)


# =============================================================================
# DEFAULT PROFILE FACTORY
# =============================================================================

def build_default_profiles() -> Dict[str, GovernanceProfile]:
    base = GovernanceProfile(
        profile_id="ggm.base",
        version="1.0",
        transition_policy={
            "transitions": {
                "epistemic:GENERATED->VERIFIED": {"mode": "FORBID", "reason": "GGM-I01"},
                "epistemic:HYPOTHESIS->VERIFIED": {
                    "mode": "GATED",
                    "requirements": {
                        "verification": [{"method": "external"}],
                        "evidence": [{"type": "external", "min_count": 1}],
                    },
                },
                "epistemic:INFERRED->VERIFIED": {
                    "mode": "GATED",
                    "requirements": {
                        "verification": [{"method": "external"}],
                        "evidence": [{"type": "supporting", "min_count": 1}],
                    },
                },
                "authority:NONE->ADVISORY": {"mode": "ALLOW"},
                "authority:ADVISORY->DELEGATED": {
                    "mode": "GATED",
                    "requirements": {
                        "authorities": [{"authority_id": "domain_owner", "min_level": "ADVISORY"}],
                        "events": ["AUTH-DELEGATE"],
                    },
                },
                "authority:DELEGATED->DOMAIN_AUTHORIZED": {
                    "mode": "GATED",
                    "requirements": {
                        "authorities": [{"authority_id": "governance_body", "min_level": "DELEGATED"}],
                        "events": ["AUTH-DOMAIN"],
                    },
                },
                "operational:RECOMMEND->EXECUTE": {"mode": "FORBID", "reason": "GGM-I10"},
                "operational:RECOMMEND->IMPLEMENT": {"mode": "FORBID", "reason": "GGM-I10"},
                "operational:RECOMMEND->PLAN": {"mode": "FORBID", "reason": "GGM-I10"},
                "lifecycle:ACTIVE->SUPERSEDED": {"mode": "ALLOW"},
            }
        },
        operational_policy={
            "consequential_execution": "GATED"
        },
        fallback_policy={
            "unknown_claim": {"epistemic_status": "UNKNOWN", "authority": "NONE"},
            "unknown_transition": {"action": "ESCALATE"},
            "missing_provenance": {"authority_upgrade": "FORBID"},
            "missing_profile": {"generation": "ALLOW", "consequential_execution": "FORBID"},
        }
    )

    software_prod = GovernanceProfile(
        profile_id="domain.software_production",
        version="1.0",
        parent_profiles=["ggm.base"],
        applies_to={"domains": ["software_production"]},
        transition_policy={
            "transitions": {
                "epistemic:GENERATED->INFERRED": {"mode": "ALLOW"},
                "authority:NONE->ADVISORY": {"mode": "ALLOW"},
            }
        },
        operational_policy={
            "consequential_execution": "ESCALATE"
        }
    )

    risk_r2 = GovernanceProfile(
        profile_id="risk.R2",
        version="1.0",
        applies_to={"risk_levels": ["R2"]},
        transition_policy={
            "transitions": {
                "authority:ADVISORY->DELEGATED": {"mode": "ESCALATE"},
                "operational:PLAN->IMPLEMENT": {
                    "mode": "GATED",
                    "requirements": {
                        "authorities": [{"authority_id": "tech_lead", "min_level": "DELEGATED"}],
                    },
                },
            }
        },
        operational_policy={
            "consequential_execution": "FORBID"
        }
    )

    risk_r3 = GovernanceProfile(
        profile_id="risk.R3",
        version="1.0",
        applies_to={"risk_levels": ["R3"]},
        transition_policy={
            "transitions": {
                "authority:DELEGATED->DOMAIN_AUTHORIZED": {"mode": "FORBID"},
                "operational:PLAN->IMPLEMENT": {"mode": "FORBID"},
                "operational:IMPLEMENT->EXECUTE": {"mode": "FORBID"},
            }
        },
        operational_policy={
            "consequential_execution": "FORBID"
        }
    )

    return {
        "ggm.base": base,
        "domain.software_production": software_prod,
        "risk.R2": risk_r2,
        "risk.R3": risk_r3,
    }