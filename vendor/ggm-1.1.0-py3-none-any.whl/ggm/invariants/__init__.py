"""ggm.invariants — hard GGM invariants (mechanical extraction from ggm_core.py)."""

from __future__ import annotations

import uuid
import json
import copy
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, List, Dict, Tuple, Set
from pathlib import Path


from ggm.model import (
    AuthorityLevel, UncertaintyLevel, ClaimFamily, GovernedClaim,
)

# =============================================================================
# MANDATORY INVARIANT IDENTITY (canonical, machine-readable)
# =============================================================================
#
# Added for P1.3 closure (D1): the invariant *identities* GGM-I01/I03/I08/I10
# already existed as inline comments/docstring references below — this
# constant does not introduce a new invariant, does not change any
# invariant's behavior, enforcement, or ID, and does not change governance
# semantics. It is purely a machine-readable name for identities that were
# previously only human-readable prose, so that other layers (e.g.
# ggm.consumption) have exactly one canonical source to read from instead of
# maintaining their own transcription.
#
# Provenance (unchanged, still enforced exactly where it already was):
#   GGM-I01, GGM-I03 — FORBIDDEN_TRANSITIONS below: epistemic GENERATED -> VERIFIED
#   GGM-I10           — FORBIDDEN_TRANSITIONS below: authority/operational escalation
#   GGM-I08           — verify_independent_confirmation()'s docstring below
MANDATORY_INVARIANT_IDS: List[str] = ["GGM-I01", "GGM-I03", "GGM-I08", "GGM-I10"]


# =============================================================================
# INVARIANT ENGINE
# =============================================================================

class GGMInvariantViolation(Exception):
    pass


class InvariantEngine:
    """
    Hard invariants. These CANNOT be disabled by profiles.
    """

    # Transitions that are FORBIDDEN regardless of qualifying events
    # because they bypass the required governance structure entirely.
    FORBIDDEN_TRANSITIONS: List[Tuple[str, str, str]] = [
        ("epistemic", "GENERATED", "VERIFIED"),      # GGM-I01, GGM-I03
        ("authority", "NONE", "DOMAIN_AUTHORIZED"),  # GGM-I10: no unqualified authority leap
        ("authority", "NONE", "GOVERNANCE_AUTHORIZED"),
        ("authority", "ADVISORY", "DOMAIN_AUTHORIZED"),
        ("authority", "DOMAIN_AUTHORIZED", "GOVERNANCE_AUTHORIZED"),
        ("operational", "RECOMMEND", "EXECUTE"),     # GGM-I10
        ("operational", "RECOMMEND", "IMPLEMENT"),   # GGM-I10: no execution path from recommendation
        ("operational", "RECOMMEND", "PLAN"),        # GGM-I10: plan requires explicit delegation
    ]

    # Epistemic properties that cannot be set to true without qualifying event
    PROTECTED_PROPERTIES = {"verified", "observed"}


    @staticmethod
    def check_transition(obj: GovernedObject, dimension: str, requested_to: str) -> None:
        current = InvariantEngine._get_current_state(obj, dimension)
        for dim, frm, to in InvariantEngine.FORBIDDEN_TRANSITIONS:
            if dim == dimension and frm == current and to == requested_to:
                raise GGMInvariantViolation(
                    f"Hard invariant blocked: {dimension} {current} -> {requested_to}"
                )

    @staticmethod
    def _get_current_state(obj: GovernedObject, dimension: str) -> str:
        if dimension == "epistemic":
            return obj.epistemic.status.value
        elif dimension == "authority":
            return obj.authority.level.value
        elif dimension == "lifecycle":
            return obj.lifecycle.status.value
        elif dimension == "operational":
            if obj.permissions.execute:
                return "EXECUTE"
            elif obj.permissions.implement:
                return "IMPLEMENT"
            elif obj.permissions.plan:
                return "PLAN"
            elif obj.permissions.recommend:
                return "RECOMMEND"
            elif obj.permissions.explore:
                return "EXPLORE"
            return "NONE"
        return "UNKNOWN"

    @staticmethod
    def check_narrative_escalation(source: GovernedObject, transformed: GovernedObject) -> Optional[str]:
        """
        Detect escalation across epistemic properties (not ordinal status),
        authority, permissions, certainty, and claim families.
        """
        violations = []

        # 1. Protected epistemic properties flipped without event
        for prop in InvariantEngine.PROTECTED_PROPERTIES:
            src_val = source.epistemic.properties.get(prop, False)
            dst_val = transformed.epistemic.properties.get(prop, False)
            if not src_val and dst_val:
                violations.append(
                    f"Epistemic property '{prop}' acquired without qualifying event"
                )

        # 2. Authority escalation
        auth_order = {
            AuthorityLevel.NONE: 0,
            AuthorityLevel.ADVISORY: 1,
            AuthorityLevel.DELEGATED: 2,
            AuthorityLevel.DOMAIN_AUTHORIZED: 3,
            AuthorityLevel.GOVERNANCE_AUTHORIZED: 4,
        }
        src_auth = auth_order.get(source.authority.level, -1)
        dst_auth = auth_order.get(transformed.authority.level, -1)
        if dst_auth > src_auth:
            violations.append(
                f"Authority escalation: {source.authority.level.value} -> {transformed.authority.level.value}"
            )

        # 3. Permission escalation
        perms = ["explore", "recommend", "plan", "implement", "execute"]
        for perm in perms:
            src_val = getattr(source.permissions, perm, False)
            dst_val = getattr(transformed.permissions, perm, False)
            if not src_val and dst_val:
                violations.append(
                    f"Permission '{perm}' acquired without transition event"
                )

        # 4. Certainty escalation (uncertainty decreasing = certainty increasing)
        certainty_rank = {
            UncertaintyLevel.UNKNOWN: 0,
            UncertaintyLevel.HIGH: 1,
            UncertaintyLevel.MEDIUM: 2,
            UncertaintyLevel.LOW: 3,
        }
        src_cert = certainty_rank.get(source.epistemic.uncertainty, -1)
        dst_cert = certainty_rank.get(transformed.epistemic.uncertainty, -1)
        if dst_cert > src_cert:
            violations.append(
                f"Certainty increased: {source.epistemic.uncertainty.value} -> {transformed.epistemic.uncertainty.value}"
            )

        # 5. Family escalation: any non-operational/non-normative -> operational/normative/decisional
        src_families = {f.value for f in source.classification.families}
        dst_families = {f.value for f in transformed.classification.families}

        # Escalatory families that require explicit transition events
        escalatory = {
            ClaimFamily.FACTUAL.value, ClaimFamily.CAUSAL.value,
            ClaimFamily.NORMATIVE.value, ClaimFamily.DECISIONAL.value,
            ClaimFamily.OPERATIONAL.value,
        }

        # HYPOTHETICAL -> anything factual/causal/normative/decisional/operational
        if ClaimFamily.HYPOTHETICAL.value in src_families:
            if dst_families & escalatory:
                violations.append(
                    f"Family escalation: HYPOTHETICAL -> {dst_families & escalatory}"
                )

        # RECOMMENDATORY -> normative/decisional/operational (recommendation laundering)
        if ClaimFamily.RECOMMENDATORY.value in src_families:
            recommend_escalatory = {
                ClaimFamily.NORMATIVE.value, ClaimFamily.DECISIONAL.value,
                ClaimFamily.OPERATIONAL.value,
            }
            if dst_families & recommend_escalatory:
                violations.append(
                    f"Family escalation: RECOMMENDATORY -> {dst_families & recommend_escalatory}"
                )

        # 6. Expressed certainty mismatch with epistemic properties
        expressed = transformed.classification.expressed_certainty
        if expressed and expressed.lower() in {"certain", "established", "proven", "definite", "absolute"}:
            if not transformed.epistemic.properties.get("verified", False):
                violations.append(
                    f"Expressed certainty '{expressed}' mismatches unverified epistemic state"
                )

        if violations:
            return " | ".join(violations)
        return None

    @staticmethod
    def verify_independent_confirmation(claim: GovernedClaim, other_claims: List[GovernedClaim]) -> bool:
        """
        GGM-I08: Agreement between models/agents is NOT independent confirmation
        if they derive from common upstream information.
        """
        for other in other_claims:
            if other.id == claim.id:
                continue
            same_producer = other.origin.producer_id == claim.origin.producer_id
            same_run = other.origin.run_id == claim.origin.run_id
            # Shared support: both depend on same upstream claims
            shared_support = bool(set(claim.support_claim_ids) & set(other.support_claim_ids))
            # Direct dependency: other directly depends on this claim
            other_depends_on_claim = claim.id in other.support_claim_ids
            # Direct dependency: this claim depends on other (circular or upstream)
            claim_depends_on_other = other.id in claim.support_claim_ids
            if not same_producer and not same_run and not shared_support and not other_depends_on_claim and not claim_depends_on_other:
                return True
        return False

