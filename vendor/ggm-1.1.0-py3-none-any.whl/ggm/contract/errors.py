"""
ggm.contract.errors — ConsumptionError, the P1.2 Consumer Contract's second,
disjoint result channel (GGM_Consumer_Contract_v1.2 §5).

ConsumptionError is a *separate type* from GovernanceResult, not a variant or
subtype of it, and the two are never conflated:

  GovernanceResult(outcome=BLOCK)  == governance evaluated the request and
                                       forbade it.
  ConsumptionError(...)            == governance could not be delivered at all.

Guarantee G3 (contract §10): these two channels remain disjoint everywhere in
the contract implementation. Nothing in this module or ggm.contract.interface
constructs a GovernanceResult in place of a ConsumptionError or vice versa.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional

from ggm.contract.types import CONTRACT_VERSION, RUNTIME_VERSION

__all__ = ["ErrorType", "ConsumptionError"]


class ErrorType(str, Enum):
    """Exhaustive per contract §5 — governance could not be delivered, for
    exactly one of these reasons."""
    CAPABILITY_NOT_AVAILABLE = "CapabilityNotAvailable"
    CONTRACT_MISMATCH = "ContractMismatch"
    RUNTIME_INTEGRITY_FAILURE = "RuntimeIntegrityFailure"
    MALFORMED_REQUEST = "MalformedRequest"


@dataclass
class ConsumptionError:
    """Contract §5. Not a GovernanceResult — a structurally distinct type,
    so the two channels cannot be conflated by construction (G3)."""
    error_type: ErrorType = ErrorType.MALFORMED_REQUEST
    request_id: Optional[str] = None
    details: str = ""
    contract_version: str = CONTRACT_VERSION
    runtime_version: str = RUNTIME_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_type": self.error_type.value,
            "request_id": self.request_id,
            "details": self.details,
            "contract_version": self.contract_version,
            "runtime_version": self.runtime_version,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConsumptionError":
        return cls(
            error_type=ErrorType(d.get("error_type", "MalformedRequest")),
            request_id=d.get("request_id"),
            details=d.get("details", ""),
            contract_version=d.get("contract_version", CONTRACT_VERSION),
            runtime_version=d.get("runtime_version", RUNTIME_VERSION),
        )
