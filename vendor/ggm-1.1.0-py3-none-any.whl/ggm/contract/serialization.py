"""
ggm.contract.serialization — canonical governed-object (de)serialization for
the P1.2 Consumer Contract boundary.

Per GGM_Consumer_Contract_v1.2 §8: the contract boundary uses serialized
governed representations and the *existing* canonical round-trip behavior
(GovernedClaim.to_dict/from_dict, GovernedRelation.to_dict/from_dict). This
module contains no new semantic object model — it only dispatches to the
correct canonical class by the `object_type` discriminator already present
on every serialized governed object (`"claim"`, `"relation"`, or the
GovernedObject base's own `"object"` default), and surfaces malformed input
as a ValueError the interface layer maps to ConsumptionError(MalformedRequest).
"""

from __future__ import annotations

from typing import Any, Dict

from ggm.model import GovernedObject, GovernedClaim, GovernedRelation

__all__ = ["deserialize_governed_object", "serialize_governed_object"]


def deserialize_governed_object(data: Dict[str, Any]) -> GovernedObject:
    """
    Reconstruct a canonical GovernedClaim/GovernedRelation/GovernedObject from
    its serialized dict form, dispatching on `object_type`. Raises ValueError
    (not the internal KeyError/TypeError) on malformed input, so the contract
    interface can uniformly translate deserialization failures into
    ConsumptionError(MalformedRequest).
    """
    if not isinstance(data, dict):
        raise ValueError("serialized governed object must be a dict")

    object_type = data.get("object_type")
    try:
        if object_type == "claim":
            return GovernedClaim.from_dict(data)
        if object_type == "relation":
            return GovernedRelation.from_dict(data)
        if object_type in (None, "object"):
            return GovernedObject.from_dict(data)
        raise ValueError(f"unknown object_type: {object_type!r}")
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError(f"malformed governed object: {e}") from e


def serialize_governed_object(obj: GovernedObject) -> Dict[str, Any]:
    """Serialize any canonical governed object via its own to_dict()."""
    return obj.to_dict()
