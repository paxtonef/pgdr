"""
ggm.contract — the GGM Consumer Contract v1.2 boundary (P1.2).

This is the only supported way for a runner to consume GGM governance.
A runner needs to import only what this package re-exports below; it
never needs InvariantEngine, ProfileResolver, TransitionEngine,
GovernanceDecisionEngine, or EscalationDetector directly.
"""

from ggm.contract.types import (
    CONTRACT_VERSION,
    RUNTIME_VERSION,
    Operation,
    TransitionAsk,
    EvidenceRef,
    ProfileTrace,
    GovernanceRequest,
    GovernanceResult,
)
from ggm.contract.errors import ErrorType, ConsumptionError
from ggm.contract.interface import GGMConsumer, DefaultGGMConsumer

__all__ = [
    "CONTRACT_VERSION",
    "RUNTIME_VERSION",
    "Operation",
    "TransitionAsk",
    "EvidenceRef",
    "ProfileTrace",
    "GovernanceRequest",
    "GovernanceResult",
    "ErrorType",
    "ConsumptionError",
    "GGMConsumer",
    "DefaultGGMConsumer",
]
