"""
ggm.contract.interface — the generic GGM consumer boundary (GGM_Consumer_Contract_v1.2 §6-7).

A runner interacts with GGM exclusively through GGMConsumer.evaluate(). It
never imports or instantiates InvariantEngine, ProfileResolver,
TransitionEngine, GovernanceDecisionEngine, or EscalationDetector directly —
DefaultGGMConsumer wires those internally, using the exact construction
pattern already used elsewhere in this codebase (see e.g.
test_ggm_adversarial.py):

    profiles = build_default_profiles()
    inv      = InvariantEngine()
    resolver = ProfileResolver(profiles)
    trans    = TransitionEngine(inv)
    esc      = EscalationDetector(inv)
    decider  = GovernanceDecisionEngine(trans, esc, resolver)

Operation mapping (contract §7 — mappings onto existing engine behavior, not
new implementations):

    DECIDE            -> GovernanceDecisionEngine.decide(...)
    TRANSITION         -> ProfileResolver.resolve(...) + TransitionEngine.evaluate(...)
    CHECK_ESCALATION   -> EscalationDetector.detect(...)

G3 (contract §10): GovernanceResult and ConsumptionError are disjoint. Every
return path below returns exactly one of the two, never a hybrid, and a
GovernanceResult is only ever constructed after an engine call actually ran.
G2 (fail closed): malformed input and unexpected internal failure both map to
ConsumptionError, never to a silent ALLOW.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Protocol, Union, runtime_checkable

from ggm.model import DecisionType
from ggm.invariants import InvariantEngine
from ggm.profiles import ProfileResolver, build_default_profiles
from ggm.governance import TransitionEngine, EscalationDetector, GovernanceDecisionEngine

from ggm.contract.types import GovernanceRequest, GovernanceResult, ProfileTrace, Operation
from ggm.contract.errors import ConsumptionError, ErrorType
from ggm.contract.serialization import deserialize_governed_object

__all__ = ["GGMConsumer", "DefaultGGMConsumer"]


@runtime_checkable
class GGMConsumer(Protocol):
    """The generic consumer boundary (§6). A runner needs nothing beyond
    this Protocol plus GovernanceRequest/GovernanceResult/ConsumptionError
    to use GGM."""

    def evaluate(self, request: GovernanceRequest) -> Union[GovernanceResult, ConsumptionError]:
        ...


class DefaultGGMConsumer:
    """Reference implementation of GGMConsumer, wiring the frozen contract's
    three operations onto the existing canonical GGM engines. This is the
    only place in ggm/contract/ that imports the engine classes; the engines
    themselves are unmodified (P1.2 makes no change to invariant, profile, or
    transition semantics)."""

    def __init__(
        self,
        profiles: Optional[Dict[str, Any]] = None,
        capability_check: Optional[Callable[[GovernanceRequest], Optional[str]]] = None,
    ):
        """
        profiles: governance profile registry; defaults to
            build_default_profiles(), the existing canonical default set.
        capability_check: optional deterministic hook returning a
            human-readable reason string if the request's capability is
            unavailable, or None if available. This is intentionally the
            *only* capability-related surface P1.2 provides — real
            Capability Profile / Consumption Resolution machinery is P1.3
            scope (contract §15). Defaults to None (no capability gating).
        """
        self.invariant = InvariantEngine()
        self.resolver = ProfileResolver(profiles if profiles is not None else build_default_profiles())
        self.transition = TransitionEngine(self.invariant)
        self.escalation = EscalationDetector(self.invariant)
        self.decider = GovernanceDecisionEngine(self.transition, self.escalation, self.resolver)
        self._capability_check = capability_check

    # ------------------------------------------------------------------
    # Public boundary
    # ------------------------------------------------------------------

    def evaluate(self, request: GovernanceRequest) -> Union[GovernanceResult, ConsumptionError]:
        request_id = self._echo_request_id(request)

        if self._capability_check is not None:
            missing = self._capability_check(request)
            if missing is not None:
                return ConsumptionError(
                    error_type=ErrorType.CAPABILITY_NOT_AVAILABLE,
                    request_id=request_id,
                    details=missing,
                )

        problems = request.validate()
        if problems:
            return ConsumptionError(
                error_type=ErrorType.MALFORMED_REQUEST,
                request_id=request_id,
                details="; ".join(problems),
            )

        try:
            obj = deserialize_governed_object(request.object)
            source_obj = (
                deserialize_governed_object(request.source_object)
                if request.source_object is not None
                else None
            )
        except ValueError as e:
            return ConsumptionError(
                error_type=ErrorType.MALFORMED_REQUEST,
                request_id=request_id,
                details=str(e),
            )

        try:
            if request.operation == Operation.DECIDE:
                return self._decide(request, obj)
            if request.operation == Operation.TRANSITION:
                return self._transition(request, obj)
            if request.operation == Operation.CHECK_ESCALATION:
                return self._check_escalation(request, obj, source_obj)
        except Exception as e:  # fail closed (G2): never let an internal
            # engine failure surface as an uncaught exception or silently
            # resolve to ALLOW — surface it as an explicit, undeliverable
            # governance error instead.
            return ConsumptionError(
                error_type=ErrorType.RUNTIME_INTEGRITY_FAILURE,
                request_id=request_id,
                details=f"{type(e).__name__}: {e}",
            )

        # Unreachable given validate() constrains operation to a known
        # Operation value, but kept explicit per G2 (fail closed, not
        # fail-open) rather than falling through implicitly.
        return ConsumptionError(
            error_type=ErrorType.MALFORMED_REQUEST,
            request_id=request_id,
            details=f"unsupported operation: {request.operation!r}",
        )

    # ------------------------------------------------------------------
    # Operation handlers — thin mappings onto existing engine behavior (§7)
    # ------------------------------------------------------------------

    def _decide(self, request: GovernanceRequest, obj) -> GovernanceResult:
        # Extra read-only resolve() call solely to surface the full audit
        # trace (profiles_applied/conflicts/relaxations); decide() performs
        # its own internal resolution (unchanged) to actually govern the
        # request. resolve() is a pure function of (obj, context, registry)
        # apart from its resolution_id/timestamp, so both calls are
        # substantively identical; we still prefer the resolution_id
        # decide() itself recorded (decision.effective_profile_id) so the
        # trace's identifier matches the resolution that actually governed
        # the decision, per G4's carve-out for non-deterministic trace ids.
        trace_profile = self.resolver.resolve(obj, request.context)

        evidence_dicts = [e.to_dict() for e in request.evidence] if request.evidence else None
        requested = [(ta.dimension, ta.to_state) for ta in request.requested_transitions] or None

        events_before = len(self.transition.events)
        decision = self.decider.decide(
            obj,
            requested_transitions=requested,
            context=request.context,
            evidence=evidence_dicts,
        )
        new_events = self.transition.events[events_before:]
        transition_event = new_events[-1].to_dict() if new_events else None

        return GovernanceResult(
            request_id=request.request_id,
            outcome=decision.decision,
            reasons=decision.reasons,
            rules_applied=decision.rules_applied,
            effective_permissions=decision.effective_permissions.to_dict(),
            repair_instruction=decision.repair_instruction,
            escalation_target=decision.escalation_target,
            transition_event=transition_event,
            profile_trace=ProfileTrace(
                profiles_applied=trace_profile.profiles_applied,
                resolution_id=decision.effective_profile_id or trace_profile.resolution_id,
                conflicts=trace_profile.conflicts,
                relaxations=trace_profile.relaxations,
            ),
        )

    def _transition(self, request: GovernanceRequest, obj) -> GovernanceResult:
        effective = self.resolver.resolve(obj, request.context)
        evidence_dicts = [e.to_dict() for e in request.evidence] if request.evidence else []

        outcome = DecisionType.ALLOW
        reasons: List[str] = []
        rules_applied: List[str] = []
        last_event = None

        # Same restrictive-precedence aggregation GovernanceDecisionEngine.decide()
        # already applies to its own requested_transitions loop (BLOCK > ESCALATE
        # > ALLOW), reused here verbatim for the narrower TRANSITION-only
        # operation rather than re-deriving new elevation semantics.
        for ta in request.requested_transitions:
            result_state, event = self.transition.evaluate(
                obj, ta.dimension, ta.to_state,
                effective_profile=effective,
                evidence=evidence_dicts,
            )
            rules_applied.extend(event.rules_applied)
            last_event = event
            if event.decision == "blocked":
                reasons.append(f"Transition {ta.dimension}->{ta.to_state} blocked")
                outcome = DecisionType.BLOCK
            elif event.decision == "escalated":
                reasons.append(f"Transition {ta.dimension}->{ta.to_state} escalated")
                if outcome != DecisionType.BLOCK:
                    outcome = DecisionType.ESCALATE
            else:
                reasons.append(f"Transition {ta.dimension}->{ta.to_state} allowed")

        return GovernanceResult(
            request_id=request.request_id,
            outcome=outcome,
            reasons=reasons,
            rules_applied=rules_applied,
            effective_permissions=obj.permissions.to_dict(),
            repair_instruction=None,
            escalation_target=None,
            transition_event=last_event.to_dict() if last_event else None,
            profile_trace=ProfileTrace(
                profiles_applied=effective.profiles_applied,
                resolution_id=effective.resolution_id,
                conflicts=effective.conflicts,
                relaxations=effective.relaxations,
            ),
        )

    def _check_escalation(self, request: GovernanceRequest, obj, source_obj) -> GovernanceResult:
        esc = self.escalation.detect(source_obj, obj)

        outcome = DecisionType.ESCALATE if esc["detected"] else DecisionType.ALLOW
        reasons: List[str] = []
        if esc["detected"]:
            if esc.get("narrative_violation"):
                reasons.append(f"Narrative escalation detected: {esc['narrative_violation']}")
            if esc.get("certainty_mismatch"):
                reasons.append("Certainty mismatch: expressed certainty exceeds epistemic properties")
            if esc.get("family_escalation"):
                reasons.append("Family escalation: hypothetical source escalated to a consequential family")
        else:
            reasons.append("No escalation detected")

        return GovernanceResult(
            request_id=request.request_id,
            outcome=outcome,
            reasons=reasons,
            # detect() applies no profile rules; rules_applied is out of scope
            # for this operation's mapping (§7) and left empty rather than
            # fabricated.
            rules_applied=[],
            effective_permissions=obj.permissions.to_dict(),
            # repair generation only happens inside decide()'s escalation
            # branch (§7 maps CHECK_ESCALATION to detect() alone), so this
            # is never populated by this operation.
            repair_instruction=None,
            # no existing engine code path ever sets escalation_target
            # (verified against ggm.governance and ggm.model) — passed
            # through faithfully as None rather than inventing a value.
            escalation_target=None,
            transition_event=None,
            # no profile resolution occurs for CHECK_ESCALATION per the §7
            # mapping — an empty trace here is accurate, not a fabricated one.
            profile_trace=ProfileTrace(),
        )

    # ------------------------------------------------------------------
    @staticmethod
    def _echo_request_id(request: GovernanceRequest) -> Optional[str]:
        rid = getattr(request, "request_id", None)
        return rid if isinstance(rid, str) and rid else None
