"""ggm.model — P0 domain model: enums and governed dataclasses (mechanical extraction from ggm_core.py)."""

from __future__ import annotations

import uuid
import json
import copy
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, List, Dict, Tuple, Set
from pathlib import Path


# =============================================================================
# ENUMS
# =============================================================================

class EpistemicStatus(str, Enum):
    UNKNOWN = "UNKNOWN"
    GENERATED = "GENERATED"
    HYPOTHESIS = "HYPOTHESIS"
    INFERRED = "INFERRED"
    SOURCED = "SOURCED"
    OBSERVED = "OBSERVED"
    VERIFIED = "VERIFIED"


class AuthorityLevel(str, Enum):
    NONE = "NONE"
    ADVISORY = "ADVISORY"
    DELEGATED = "DELEGATED"
    DOMAIN_AUTHORIZED = "DOMAIN_AUTHORIZED"
    GOVERNANCE_AUTHORIZED = "GOVERNANCE_AUTHORIZED"


class RiskLevel(str, Enum):
    R0 = "R0"
    R1 = "R1"
    R2 = "R2"
    R3 = "R3"


class LifecycleStatus(str, Enum):
    ACTIVE = "ACTIVE"
    SUPERSEDED = "SUPERSEDED"
    REJECTED = "REJECTED"
    RETRACTED = "RETRACTED"
    EXPIRED = "EXPIRED"


class ClaimFamily(str, Enum):
    FACTUAL = "FACTUAL"
    INFERENTIAL = "INFERENTIAL"
    HYPOTHETICAL = "HYPOTHETICAL"
    CAUSAL = "CAUSAL"
    NORMATIVE = "NORMATIVE"
    RECOMMENDATORY = "RECOMMENDATORY"
    DECISIONAL = "DECISIONAL"
    OPERATIONAL = "OPERATIONAL"


class RelationType(str, Enum):
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    CAUSES = "causes"
    CONTRIBUTES_TO = "contributes_to"
    REQUIRES = "requires"
    IMPLIES = "implies"
    DEPENDS_ON = "depends_on"
    AUTHORIZES = "authorizes"
    SUPERSEDES = "supersedes"


class TransitionMode(str, Enum):
    ALLOW = "ALLOW"
    GATED = "GATED"
    ESCALATE = "ESCALATE"
    FORBID = "FORBID"


class DecisionType(str, Enum):
    ALLOW = "ALLOW"
    REPAIR = "REPAIR"
    LABEL = "LABEL"
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"


class UncertaintyLevel(str, Enum):
    UNKNOWN = "UNKNOWN"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class OriginType(str, Enum):
    USER = "user"
    SOURCE = "source"
    LLM = "llm"
    DETERMINISTIC_SYSTEM = "deterministic_system"
    EXTERNAL_SYSTEM = "external_system"


# =============================================================================
# DATACLASSES
# =============================================================================

@dataclass
class Origin:
    origin_type: OriginType
    producer_id: str
    run_id: Optional[str] = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "origin_type": self.origin_type.value,
            "producer_id": self.producer_id,
            "run_id": self.run_id,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Origin":
        return cls(
            origin_type=OriginType(d["origin_type"]),
            producer_id=d["producer_id"],
            run_id=d.get("run_id"),
            timestamp=datetime.fromisoformat(d["timestamp"]),
        )


@dataclass
class Classification:
    families: List[ClaimFamily] = field(default_factory=list)
    confidence: float = 0.0
    ambiguous: bool = False
    alternatives: List[ClaimFamily] = field(default_factory=list)
    expressed_certainty: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "families": [f.value for f in self.families],
            "confidence": self.confidence,
            "ambiguous": self.ambiguous,
            "alternatives": [f.value for f in self.alternatives],
            "expressed_certainty": self.expressed_certainty,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Classification":
        return cls(
            families=[ClaimFamily(f) for f in d.get("families", [])],
            confidence=d.get("confidence", 0.0),
            ambiguous=d.get("ambiguous", False),
            alternatives=[ClaimFamily(f) for f in d.get("alternatives", [])],
            expressed_certainty=d.get("expressed_certainty"),
        )


@dataclass
class EpistemicState:
    """Coexisting epistemic properties — NOT an ordinal ladder."""
    properties: Dict[str, bool] = field(default_factory=dict)
    status: EpistemicStatus = EpistemicStatus.UNKNOWN
    uncertainty: UncertaintyLevel = UncertaintyLevel.UNKNOWN
    contested: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "properties": self.properties,
            "status": self.status.value,
            "uncertainty": self.uncertainty.value,
            "contested": self.contested,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EpistemicState":
        return cls(
            properties=d.get("properties", {}),
            status=EpistemicStatus(d.get("status", "UNKNOWN")),
            uncertainty=UncertaintyLevel(d.get("uncertainty", "UNKNOWN")),
            contested=d.get("contested", False),
        )


@dataclass
class AuthorityState:
    level: AuthorityLevel = AuthorityLevel.NONE
    authority_id: Optional[str] = None
    authorization_event_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "level": self.level.value,
            "authority_id": self.authority_id,
            "authorization_event_id": self.authorization_event_id,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AuthorityState":
        return cls(
            level=AuthorityLevel(d.get("level", "NONE")),
            authority_id=d.get("authority_id"),
            authorization_event_id=d.get("authorization_event_id"),
        )


@dataclass
class Permissions:
    present: bool = False
    explore: bool = False
    recommend: bool = False
    plan: bool = False
    implement: bool = False
    execute: bool = False
    persist: bool = False
    propagate: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Permissions":
        return cls(**{k: d.get(k, False) for k in [
            "present", "explore", "recommend", "plan", "implement", "execute", "persist", "propagate"
        ]})


@dataclass
class RiskAssessment:
    level: RiskLevel = RiskLevel.R0
    rationale: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {"level": self.level.value, "rationale": self.rationale}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RiskAssessment":
        return cls(
            level=RiskLevel(d.get("level", "R0")),
            rationale=d.get("rationale", []),
        )


@dataclass
class Lifecycle:
    status: LifecycleStatus = LifecycleStatus.ACTIVE
    superseded_by: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"status": self.status.value, "superseded_by": self.superseded_by}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Lifecycle":
        return cls(
            status=LifecycleStatus(d.get("status", "ACTIVE")),
            superseded_by=d.get("superseded_by"),
        )


@dataclass
class Provenance:
    parent_objects: List[str] = field(default_factory=list)
    transformation_events: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Provenance":
        return cls(
            parent_objects=d.get("parent_objects", []),
            transformation_events=d.get("transformation_events", []),
        )


@dataclass
class GovernedObject:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object_type: str = "object"
    content: str = ""
    origin: Origin = field(default_factory=lambda: Origin(
        origin_type=OriginType.DETERMINISTIC_SYSTEM,
        producer_id="ggm_core"
    ))
    classification: Classification = field(default_factory=Classification)
    epistemic: EpistemicState = field(default_factory=EpistemicState)
    authority: AuthorityState = field(default_factory=AuthorityState)
    permissions: Permissions = field(default_factory=Permissions)
    risk: RiskAssessment = field(default_factory=RiskAssessment)
    lifecycle: Lifecycle = field(default_factory=Lifecycle)
    provenance: Provenance = field(default_factory=Provenance)
    effective_profile_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "object_type": self.object_type,
            "content": self.content,
            "origin": self.origin.to_dict(),
            "classification": self.classification.to_dict(),
            "epistemic": self.epistemic.to_dict(),
            "authority": self.authority.to_dict(),
            "permissions": self.permissions.to_dict(),
            "risk": self.risk.to_dict(),
            "lifecycle": self.lifecycle.to_dict(),
            "provenance": self.provenance.to_dict(),
            "effective_profile_id": self.effective_profile_id,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernedObject":
        return cls(
            id=d["id"],
            object_type=d.get("object_type", "object"),
            content=d.get("content", ""),
            origin=Origin.from_dict(d["origin"]),
            classification=Classification.from_dict(d.get("classification", {})),
            epistemic=EpistemicState.from_dict(d.get("epistemic", {})),
            authority=AuthorityState.from_dict(d.get("authority", {})),
            permissions=Permissions.from_dict(d.get("permissions", {})),
            risk=RiskAssessment.from_dict(d.get("risk", {})),
            lifecycle=Lifecycle.from_dict(d.get("lifecycle", {})),
            provenance=Provenance.from_dict(d.get("provenance", {})),
            effective_profile_id=d.get("effective_profile_id"),
        )


@dataclass
class GovernedClaim(GovernedObject):
    object_type: str = "claim"
    support_claim_ids: List[str] = field(default_factory=list)
    support_source_ids: List[str] = field(default_factory=list)
    support_verification_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d["support_claim_ids"] = self.support_claim_ids
        d["support_source_ids"] = self.support_source_ids
        d["support_verification_ids"] = self.support_verification_ids
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernedClaim":
        base = GovernedObject.from_dict(d)
        return cls(
            id=base.id,
            object_type=base.object_type,
            content=base.content,
            origin=base.origin,
            classification=base.classification,
            epistemic=base.epistemic,
            authority=base.authority,
            permissions=base.permissions,
            risk=base.risk,
            lifecycle=base.lifecycle,
            provenance=base.provenance,
            effective_profile_id=base.effective_profile_id,
            support_claim_ids=d.get("support_claim_ids", []),
            support_source_ids=d.get("support_source_ids", []),
            support_verification_ids=d.get("support_verification_ids", []),
        )


@dataclass
class GovernedRelation(GovernedObject):
    object_type: str = "relation"
    from_claim_id: str = ""
    to_claim_id: str = ""
    relation_type: RelationType = RelationType.SUPPORTS

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d["from_claim_id"] = self.from_claim_id
        d["to_claim_id"] = self.to_claim_id
        d["relation_type"] = self.relation_type.value
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernedRelation":
        base = GovernedObject.from_dict(d)
        return cls(
            id=base.id,
            object_type=base.object_type,
            content=base.content,
            origin=base.origin,
            classification=base.classification,
            epistemic=base.epistemic,
            authority=base.authority,
            permissions=base.permissions,
            risk=base.risk,
            lifecycle=base.lifecycle,
            provenance=base.provenance,
            effective_profile_id=base.effective_profile_id,
            from_claim_id=d.get("from_claim_id", ""),
            to_claim_id=d.get("to_claim_id", ""),
            relation_type=RelationType(d.get("relation_type", "supports")),
        )


@dataclass
class TransitionRule:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    dimension: str = ""
    from_state: str = ""
    to_state: str = ""
    mode: TransitionMode = TransitionMode.FORBID
    requirements: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    risk_conditions: List[str] = field(default_factory=list)
    reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dimension": self.dimension,
            "from_state": self.from_state,
            "to_state": self.to_state,
            "mode": self.mode.value,
            "requirements": self.requirements,
            "risk_conditions": self.risk_conditions,
            "reason": self.reason,
        }


@dataclass
class TransitionEvent:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object_id: str = ""
    dimension: str = ""
    previous_state: str = ""
    requested_state: str = ""
    resulting_state: str = ""
    trigger_type: str = ""
    actor_id: Optional[str] = None
    source_id: Optional[str] = None
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    rules_applied: List[str] = field(default_factory=list)
    decision: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "object_id": self.object_id,
            "dimension": self.dimension,
            "previous_state": self.previous_state,
            "requested_state": self.requested_state,
            "resulting_state": self.resulting_state,
            "trigger_type": self.trigger_type,
            "actor_id": self.actor_id,
            "source_id": self.source_id,
            "evidence": self.evidence,
            "rules_applied": self.rules_applied,
            "decision": self.decision,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TransitionEvent":
        return cls(
            id=d["id"],
            object_id=d.get("object_id", ""),
            dimension=d.get("dimension", ""),
            previous_state=d.get("previous_state", ""),
            requested_state=d.get("requested_state", ""),
            resulting_state=d.get("resulting_state", ""),
            trigger_type=d.get("trigger_type", ""),
            actor_id=d.get("actor_id"),
            source_id=d.get("source_id"),
            evidence=d.get("evidence", []),
            rules_applied=d.get("rules_applied", []),
            decision=d.get("decision", ""),
            timestamp=datetime.fromisoformat(d["timestamp"]),
        )


@dataclass
class GovernanceDecision:
    object_id: str = ""
    decision: DecisionType = DecisionType.BLOCK
    reasons: List[str] = field(default_factory=list)
    rules_applied: List[str] = field(default_factory=list)
    effective_permissions: Permissions = field(default_factory=Permissions)
    repair_instruction: Optional[str] = None
    escalation_target: Optional[str] = None
    effective_profile_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object_id": self.object_id,
            "decision": self.decision.value,
            "reasons": self.reasons,
            "rules_applied": self.rules_applied,
            "effective_permissions": self.effective_permissions.to_dict(),
            "repair_instruction": self.repair_instruction,
            "escalation_target": self.escalation_target,
            "effective_profile_id": self.effective_profile_id,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GovernanceDecision":
        return cls(
            object_id=d.get("object_id", ""),
            decision=DecisionType(d.get("decision", "BLOCK")),
            reasons=d.get("reasons", []),
            rules_applied=d.get("rules_applied", []),
            effective_permissions=Permissions.from_dict(d.get("effective_permissions", {})),
            repair_instruction=d.get("repair_instruction"),
            escalation_target=d.get("escalation_target"),
            effective_profile_id=d.get("effective_profile_id"),
        )

