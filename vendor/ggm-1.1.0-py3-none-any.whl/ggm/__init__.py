"""ggm — Generation Governance Model package (mechanical extraction from the former ggm_core.py monolith)."""

from ggm.model import (
    EpistemicStatus, AuthorityLevel, RiskLevel, LifecycleStatus,
    ClaimFamily, RelationType, TransitionMode, DecisionType,
    UncertaintyLevel, OriginType,
    Origin, Classification, EpistemicState, AuthorityState,
    Permissions, RiskAssessment, Lifecycle, Provenance,
    GovernedObject, GovernedClaim, GovernedRelation,
    TransitionRule, TransitionEvent, GovernanceDecision,
)
from ggm.profiles import GovernanceProfile, EffectiveProfile, ProfileResolver, build_default_profiles
from ggm.invariants import GGMInvariantViolation, InvariantEngine
from ggm.governance import TransitionEngine, EscalationDetector, GovernanceDecisionEngine
from ggm.persistence import ClaimStore

__all__ = [
    "EpistemicStatus", "AuthorityLevel", "RiskLevel", "LifecycleStatus",
    "ClaimFamily", "RelationType", "TransitionMode", "DecisionType",
    "UncertaintyLevel", "OriginType",
    "Origin", "Classification", "EpistemicState", "AuthorityState",
    "Permissions", "RiskAssessment", "Lifecycle", "Provenance",
    "GovernedObject", "GovernedClaim", "GovernedRelation",
    "TransitionRule", "TransitionEvent",
    "GovernanceProfile", "EffectiveProfile", "GovernanceDecision",
    "GGMInvariantViolation", "InvariantEngine", "ProfileResolver",
    "TransitionEngine", "EscalationDetector", "GovernanceDecisionEngine",
    "ClaimStore", "build_default_profiles",
]


if __name__ == "__main__":
    print("GGM Core v1.1 loaded. Import this module to use the governance engine.")